---
name: notebooklm-pptx-editable
description: Convierte presentaciones exportadas por NotebookLM (PPTX o PDF donde cada diapositiva es una imagen plana y el texto no se puede editar) en un PowerPoint editable que conserva el estilo visual original — mismo fondo, colores, posiciones y jerarquía tipográfica — pero con cuadros de texto nativos. Recibe la ruta (relativa o absoluta) del archivo. Usa esta skill siempre que el usuario mencione NotebookLM junto con diapositivas, slides, PowerPoint o presentaciones; cuando diga que un PPTX "es pura imagen", "no deja editar el texto", "viene aplanado" o "está rasterizado"; o cuando pida "hacer editable", "recuperar el texto" o "reconstruir" un deck generado por IA, aunque no nombre NotebookLM.
---

# NotebookLM → PPTX editable

NotebookLM exporta cada diapositiva como **una sola imagen** a pantalla completa. Esta skill
reconstruye el deck en tres capas: (1) el fondo original **con el texto borrado**, (2) cuadros
de texto **nativos** en la misma posición, tamaño, color y peso, y (3) notas del orador
conservadas. El resultado se ve casi igual pero cada texto se edita en PowerPoint.

El trabajo se divide en una parte mecánica (scripts: extracción, OCR, limpieza, armado) y
una parte de criterio (tú: corregir el OCR, decidir qué texto pertenece a una ilustración,
elegir la fuente, revisar visualmente). La calidad final depende de la segunda parte;
no la saltes.

## Requisitos

Ejecuta primero `python <skill>/scripts/nlm2pptx.py doctor`. Necesita Python con
`python-pptx opencv-python-headless numpy Pillow lxml` y el binario **Tesseract OCR**.
El modelo de español se descarga solo si falta. LibreOffice y poppler son opcionales
(render de verificación y entrada PDF). Si algo falta, consulta `resources/instalacion.md`.

`<skill>` = carpeta donde está este SKILL.md.

## Flujo

### 1. Resolver la ruta y analizar

El usuario dará una ruta relativa (p. ej. `./decks/estrategia.pptx` o solo `estrategia.pptx`).
Pásala tal cual: el script la resuelve contra el directorio actual y, si no existe, busca el
nombre en subcarpetas del cwd y en `/mnt/user-data/uploads` (Claude.ai). No adivines rutas:
si el script reporta varias coincidencias o ninguna, pregunta.

```bash
python <skill>/scripts/nlm2pptx.py analyze <ruta> [--lang spa,eng] [--font "Arial"] [--out salida.pptx]
```

Crea `<nombre>_nlm2pptx_work/` con `slides/` (imágenes originales), `layout.json` (bloques de
texto detectados) y `review/overlays_sheet_N.png` (cada bloque recuadrado con su id y tamaño;
en rojo los de baja confianza). Salida por defecto: `<nombre>_editable.pptx` junto al original
(en Claude.ai, `/mnt/user-data/outputs/`).

### 2. Revisar y corregir `layout.json` (paso clave)

Mira las hojas de overlays **y** las imágenes originales de `slides/` y corrige el JSON.
El esquema completo está en `resources/layout-schema.md`. Revisa, en este orden:

1. **Texto.** El OCR confunde tildes, ñ, comillas, guiones y letras en fuentes grandes. Lee
   cada bloque contra la imagen y corrige `paragraphs[].text`. Es lo que más valora el
   usuario: un deck editable con faltas de ortografía no sirve.
2. **Texto de ilustraciones.** Etiquetas dentro de diagramas, iconos o gráficos suelen
   quedar mejor como parte de la imagen. Para dejarlas como estaban:
   `"skip": true, "remove_from_background": false`. Si el usuario quiere todo editable,
   mantenlas pero verifica el borrado en la comparativa.
3. **Agrupación.** Une bloques que son un mismo párrafo/lista y separa los que el OCR mezcló
   (dos columnas en una línea). Las líneas que el original partió por ancho ya vienen unidas
   en un solo párrafo para que el texto fluya al editar; deshaz la unión si eran ideas distintas.
4. **Viñetas.** `"bullet": true` por párrafo (el símbolo original se borra del fondo).
   Para viñetas no detectadas, márcalas y añade `erase_boxes_px` sobre el símbolo si no se borró.
5. **Estilo.** `bold`, `color`, `align` y `font_size_pt` son estimaciones; ajústalas si la
   imagen muestra otra cosa. Mantén tamaños coherentes entre slides (todos los títulos igual).
6. **Fuente.** Identifica el estilo tipográfico y fija `defaults.font_family` con una fuente que
   el usuario tendrá instalada. Guía en `resources/fuentes.md`. Si el usuario nombra una fuente
   corporativa, úsala.
7. **Roles.** Un bloque por slide con `"role": "title"` va al marcador de título de PowerPoint
   (navegación, accesibilidad, esquema). Corrige si el título detectado no es el correcto.

Edita el JSON con un script de Python pequeño o con reemplazos puntuales; no lo reescribas a
mano entero en decks largos.

### 3. Construir y verificar

```bash
python <skill>/scripts/nlm2pptx.py build <carpeta_work> [--out salida.pptx]
```

Borra el texto de cada imagen (relleno por modelo de degradado cuando el fondo es liso o en
degradado, *inpainting* cuando hay textura), arma el PPTX con el fondo limpio como **fondo de
diapositiva** (no seleccionable, así no se arrastra al editar) y genera
`review/compare_sheet_N.png` (original | editable renderizado).

Mira **todas** las comparativas y busca: texto mal ubicado o con saltos de línea distintos,
tamaños desproporcionados, restos/fantasmas del texto viejo en el fondo, manchas por
*inpainting* sobre ilustraciones, textos que se salen de su tarjeta. Corrige `layout.json`
(`font_size_pt`, `box_px` para fijar la caja exacta, `skip`, `erase_boxes_px`, etc.) y vuelve a
correr `build`. Normalmente bastan 1–2 iteraciones. La comparativa usa LibreOffice; pequeñas
diferencias de fuente frente a PowerPoint son normales.

Ejecuta también el validador de la skill `pptx` si está disponible
(`python <pptx-skill>/scripts/office/validate.py salida.pptx`).

### 4. Entregar

Entrega el `.pptx` (en Claude.ai: copia a `/mnt/user-data/outputs/` y preséntalo). Resume en
2–4 líneas: número de slides, qué quedó editable, qué se dejó como imagen a propósito y
cualquier limitación visible (p. ej. una mancha leve donde el texto estaba sobre una foto).

## Modo rápido

`nlm2pptx.py all <ruta>` encadena analyze + build sin revisión. Úsalo solo si el usuario pide
explícitamente un borrador rápido, y avísale de que el texto no está revisado.

## Casos especiales

- **Slide con varias imágenes o que no es imagen completa:** se renderiza el slide completo
  con LibreOffice y se trata como imagen (verás un aviso en el log).
- **Texto sobre fotografía o textura:** el borrado puede dejar una mancha. Opciones: aceptar,
  marcar el bloque `skip` (queda como imagen) o poner `"keep_original_background": true` en
  el slide y aceptar que el texto viejo quede debajo (rara vez es buena idea).
- **Idiomas:** `--lang spa,eng` por defecto; añade `por`, `fra`, etc. si el deck los usa.
- **Decks largos (20+ slides):** revisa por hojas de 6; corrige en lote con un script
  (p. ej., unificar el tamaño de todos los títulos).

## Recursos

- `resources/layout-schema.md` — campos de `layout.json` y qué hace cada uno al construir.
- `resources/fuentes.md` — cómo elegir la fuente equivalente.
- `resources/instalacion.md` — dependencias por sistema operativo.
- `scripts/nlm2pptx.py` — CLI (`doctor`, `analyze`, `build`, `all`). Módulos: `extract.py`,
  `ocr.py`, `clean.py`, `build.py`, `compare.py`.
