# Elegir la fuente equivalente

NotebookLM genera las diapositivas con tipografías sans-serif modernas (familia tipo
Google Sans / geométricas) y, según el estilo elegido, a veces una serif para títulos.
La fuente original casi nunca está instalada en el equipo del usuario, así que elige una
que **sí** esté disponible donde se va a editar el deck:

| Lo que ves en la imagen | Opción Windows/Office | Multiplataforma (Google Slides) |
|---|---|---|
| Sans geométrica, "a" de un piso o redondeada | Segoe UI, Century Gothic | Poppins, Montserrat |
| Sans neutra (la más común en NotebookLM) | Segoe UI, Arial, Calibri | Inter, Roboto, Open Sans |
| Sans condensada en títulos | Arial Narrow, Bahnschrift | Roboto Condensed, Oswald |
| Serif elegante en títulos | Georgia, Cambria | Playfair Display, Merriweather |
| Monoespaciada (código) | Consolas | Roboto Mono |

Criterios:

1. Si el usuario nombra una fuente (corporativa o no), úsala siempre.
2. Si el deck se editará en PowerPoint de escritorio sin indicación, **Segoe UI** o **Arial**
   son apuestas seguras; si va a Google Slides, **Inter** o **Roboto**.
3. Puedes usar dos familias: `defaults.font_family` para el cuerpo y `font_family` en los
   bloques `title` para títulos.
4. Las fuentes anchas (Segoe UI, Verdana) ocupan más que Arial; si en la comparativa el texto
   salta de línea más que el original, baja `font_size_pt` medio punto o ensancha `box_px`.
5. El render de verificación usa LibreOffice: si la fuente elegida no está instalada en el
   entorno, se sustituye y los saltos de línea pueden variar. Eso no indica un error en el PPTX.
