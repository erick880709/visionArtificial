# Instalación de dependencias

## Python (todas las plataformas)

```bash
pip install python-pptx opencv-python-headless numpy Pillow lxml
# en entornos gestionados (Claude.ai): añade --break-system-packages
```

## Tesseract OCR (obligatorio)

| Sistema | Comando |
|---|---|
| Ubuntu/Debian | `sudo apt-get install -y tesseract-ocr tesseract-ocr-spa` |
| macOS | `brew install tesseract tesseract-lang` |
| Windows | `winget install UB-Mannheim.TesseractOCR` (marca *Spanish* en el instalador) y añade `C:\Program Files\Tesseract-OCR` al PATH |

Si falta el modelo de español, `nlm2pptx.py` lo descarga a `~/.cache/nlm2pptx/tessdata`
(cámbialo con la variable `NLM2PPTX_TESSDATA`). Sin red, sigue con los idiomas instalados.

## Opcionales

- **LibreOffice** — render de verificación (`review/compare_*.png`) y slides que no son una
  sola imagen. Ubuntu: `sudo apt-get install -y libreoffice-impress`; macOS: `brew install --cask libreoffice`.
- **poppler** (`pdftoppm`) — entrada PDF y verificación. Ubuntu: `poppler-utils`;
  macOS: `brew install poppler`; Windows: `winget install oschwartz10612.Poppler`.

Comprueba todo con `python scripts/nlm2pptx.py doctor`.
