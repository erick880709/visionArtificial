# Esquema de `layout.json`

Coordenadas en **píxeles de la imagen original** del slide (`*_px`); tamaños en **puntos**.
`build` convierte a EMU usando `placement_emu` (dónde estaba la imagen en el slide).

## Raíz

| Campo | Uso |
|---|---|
| `defaults.font_family` | Fuente de todo el deck salvo que un bloque/párrafo diga otra. |
| `slide_width_emu`, `slide_height_emu` | Tamaño del slide original. No tocar. |
| `source`, `output` | Archivo de entrada y ruta de salida por defecto. |
| `slides[]` | Un objeto por diapositiva. |

## Slide

| Campo | Uso |
|---|---|
| `index`, `image`, `image_px`, `placement_emu` | Generados. No tocar. |
| `notes` | Notas del orador del original; se copian al nuevo deck. Editables. |
| `blocks[]` | Cuadros de texto. El orden es el orden de tabulación/lectura. |
| `keep_original_background` | `true` = no borrar texto de este slide (texto viejo queda debajo). |
| `background` | Lo escribe `build` (fondo limpio). |

## Bloque

| Campo | Uso |
|---|---|
| `id` | Identificador visible en los overlays (`s3b2` = slide 3, bloque 2). |
| `role` | `title` → marcador de título de PowerPoint (uno por slide). Otro valor → cuadro de texto. |
| `paragraphs[]` | Párrafos (ver abajo). |
| `font_size_pt` | Tamaño base. |
| `line_pitch_pt` | Interlineado exacto medido (null = sencillo). |
| `paragraph_spacing_pt` | Espacio antes de cada párrafo excepto el primero (listas espaciadas). |
| `color`, `bg_color` | Hex sin `#`. `bg_color` solo se usa para borrar el texto del fondo. |
| `bold`, `italic`, `align` | `align`: `left` · `center` · `right` · `justify`. |
| `font_family` | Opcional, sobrescribe `defaults.font_family`. |
| `bullet_indent_pt`, `bullet_color` | Sangría y color de la viñeta (detectados). |
| `bbox_px` | Caja de la tinta detectada. `build` la amplía un poco para la caja de texto. |
| `box_px` | Opcional `[x,y,w,h]`: caja **exacta** del cuadro de texto, sin ajustes automáticos. Úsalo para alinear con una tarjeta o cuando el texto se sale. |
| `line_boxes_px` | Cajas por línea; definen qué se borra del fondo. Si editas `bbox_px` a mano y borras este campo, se borra el `bbox_px`. |
| `erase_boxes_px` | Rectángulos extra a borrar del fondo (símbolos sueltos, restos). |
| `remove_from_background` | `false` = no borrar este texto de la imagen. |
| `skip` | `true` = no crear cuadro de texto. Con `remove_from_background: false` el texto queda como parte de la imagen. |
| `ocr_conf`, `stroke_ratio` | Diagnóstico (confianza OCR; grosor de trazo ≥0.14 ≈ negrita). Ignorados al construir. |

## Párrafo

```json
{"text": "Mínimo privilegio para identidades", "bullet": true, "level": 0}
```

Campos opcionales: `bullet`, `level` (0–4), `align`, `bold`, `italic`, `color`, `font_size_pt`,
`font_family`, `space_before_pt`, `bullet_color`, y `runs` para estilos mixtos dentro del párrafo:

```json
{"runs": [{"text": "Clave: ", "bold": true}, {"text": "cifrado de extremo a extremo"}]}
```

Si hay `runs`, se ignora `text`. `wrapped_lines` es informativo (cuántas líneas ocupaba en el original).

## Ejemplo de corrección en lote

```python
import json; p = "deck_nlm2pptx_work/layout.json"; L = json.load(open(p, encoding="utf-8"))
L["defaults"]["font_family"] = "Segoe UI"
for s in L["slides"]:
    for b in s["blocks"]:
        if b["role"] == "title":
            b["font_size_pt"] = 36; b["bold"] = True
json.dump(L, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
```
