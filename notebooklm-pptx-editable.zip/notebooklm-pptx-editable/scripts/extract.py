"""Fase 1a: extrae la imagen de cada slide del PPTX (o PDF) de NotebookLM."""
import io
from pathlib import Path

from PIL import Image

from common import EMU_PER_INCH, log, run, find_soffice


def _render_slides_with_soffice(src: Path, outdir: Path):
    """Plan B: renderiza el PPTX completo a PNG (cuando un slide no es una sola imagen)."""
    soffice = find_soffice()
    if not soffice:
        return {}
    tmp = outdir / "_render"
    tmp.mkdir(exist_ok=True)
    profile = (tmp / "lo_profile").resolve().as_uri()
    run([soffice, f"-env:UserInstallation={profile}", "--headless",
         "--convert-to", "pdf", "--outdir", str(tmp), str(src)], timeout=300)
    pdf = tmp / (src.stem + ".pdf")
    if not pdf.exists():
        return {}
    run(["pdftoppm", "-r", "150", "-png", str(pdf), str(tmp / "p")], timeout=300)
    pages = sorted(tmp.glob("p-*.png"))
    return {i + 1: p for i, p in enumerate(pages)}


def extract_pptx(src: Path, workdir: Path):
    from pptx import Presentation
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    prs = Presentation(str(src))
    sw, sh = prs.slide_width, prs.slide_height
    imgdir = workdir / "slides"
    imgdir.mkdir(parents=True, exist_ok=True)
    manifest = {"source": str(src), "source_type": "pptx",
                "slide_width_emu": int(sw), "slide_height_emu": int(sh), "slides": []}
    rendered = None

    for idx, slide in enumerate(prs.slides, start=1):
        pics, other_text = [], []
        for shp in slide.shapes:
            if shp.shape_type == MSO_SHAPE_TYPE.PICTURE:
                pics.append(shp)
            elif shp.has_text_frame and shp.text_frame.text.strip():
                other_text.append(shp.text_frame.text.strip())
        notes = ""
        if slide.has_notes_slide:
            notes = slide.notes_slide.notes_text_frame.text.strip()

        entry = {"index": idx, "notes": notes, "native_text": other_text, "warnings": []}
        out = imgdir / f"slide_{idx:02d}.png"
        if pics:
            big = max(pics, key=lambda s: int(s.width) * int(s.height))
            coverage = (int(big.width) * int(big.height)) / (int(sw) * int(sh))
            img = Image.open(io.BytesIO(big.image.blob)).convert("RGB")
            if coverage >= 0.85 and len(pics) == 1:
                img.save(out)
                entry["placement_emu"] = [int(big.left), int(big.top), int(big.width), int(big.height)]
            else:
                entry["warnings"].append(
                    f"slide con {len(pics)} imágenes (cobertura mayor={coverage:.0%}); se renderiza completo")
                pics = []
        if not pics:
            if rendered is None:
                rendered = _render_slides_with_soffice(src, workdir)
            if idx in rendered:
                Image.open(rendered[idx]).convert("RGB").save(out)
                entry["placement_emu"] = [0, 0, int(sw), int(sh)]
            else:
                entry["warnings"].append("no se pudo obtener imagen del slide")
                continue
        im = Image.open(out)
        entry["image"] = str(out.relative_to(workdir))
        entry["image_px"] = list(im.size)
        manifest["slides"].append(entry)
        log(f"slide {idx}: {im.size[0]}x{im.size[1]} px" + (f"  ⚠ {entry['warnings']}" if entry["warnings"] else ""))
    return manifest


def extract_pdf(src: Path, workdir: Path):
    imgdir = workdir / "slides"
    imgdir.mkdir(parents=True, exist_ok=True)
    r = run(["pdftoppm", "-r", "200", "-png", str(src), str(imgdir / "p")], timeout=600)
    if r.returncode != 0:
        raise SystemExit("ERROR: pdftoppm falló: " + r.stderr)
    pages = sorted(imgdir.glob("p-*.png"))
    first = Image.open(pages[0])
    w, h = first.size
    sw = int(13.333 * EMU_PER_INCH)
    sh = int(sw * h / w)
    manifest = {"source": str(src), "source_type": "pdf",
                "slide_width_emu": sw, "slide_height_emu": sh, "slides": []}
    for i, p in enumerate(pages, start=1):
        out = imgdir / f"slide_{i:02d}.png"
        p.rename(out)
        im = Image.open(out)
        manifest["slides"].append({"index": i, "notes": "", "native_text": [], "warnings": [],
                                   "image": str(out.relative_to(workdir)), "image_px": list(im.size),
                                   "placement_emu": [0, 0, sw, sh]})
        log(f"página {i}: {im.size[0]}x{im.size[1]} px")
    return manifest


def extract(src: Path, workdir: Path):
    ext = src.suffix.lower()
    if ext == ".pptx":
        return extract_pptx(src, workdir)
    if ext == ".pdf":
        return extract_pdf(src, workdir)
    raise SystemExit(f"ERROR: formato no soportado '{ext}' (usa .pptx o .pdf)")
