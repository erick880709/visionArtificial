"""Utilidades compartidas por los scripts de notebooklm-pptx-editable."""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

EMU_PER_INCH = 914400
EMU_PER_PT = 12700

SEARCH_DIRS = ["/mnt/user-data/uploads", "/mnt/user-data/outputs", "."]


def log(msg):
    print(f"[nlm2pptx] {msg}", flush=True)


def resolve_input(raw_path: str) -> Path:
    """Resuelve una ruta relativa o absoluta. Si no existe tal cual, busca el
    nombre del archivo en el directorio actual (hasta 3 niveles) y en las
    carpetas de carga habituales."""
    p = Path(os.path.expanduser(raw_path))
    if p.is_file():
        return p.resolve()
    cand = Path.cwd() / p
    if cand.is_file():
        return cand.resolve()
    name = p.name
    hits = []
    for base in SEARCH_DIRS:
        b = Path(base)
        if not b.is_dir():
            continue
        for pattern in [name, f"*/{name}", f"*/*/{name}", f"*/*/*/{name}"]:
            hits.extend(x for x in b.glob(pattern) if x.is_file())
    hits = sorted({h.resolve() for h in hits})
    if len(hits) == 1:
        log(f"'{raw_path}' no existe tal cual; se usa {hits[0]}")
        return hits[0]
    if len(hits) > 1:
        sys.exit("ERROR: varios archivos coinciden con '%s':\n  %s\nIndica la ruta exacta."
                 % (raw_path, "\n  ".join(map(str, hits))))
    sys.exit(f"ERROR: no se encontró el archivo '{raw_path}' (cwd={Path.cwd()}).")


def default_output_path(src: Path) -> Path:
    """<nombre>_editable.pptx junto al original; si esa carpeta es de solo
    lectura, en /mnt/user-data/outputs o en el cwd."""
    name = f"{src.stem}_editable.pptx"
    for d in [src.parent, Path("/mnt/user-data/outputs"), Path.cwd()]:
        if d.is_dir() and os.access(d, os.W_OK):
            return d / name
    return Path.cwd() / name


def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def save_json(obj, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def find_soffice():
    for name in ["soffice", "libreoffice"]:
        p = shutil.which(name)
        if p:
            return p
    for p in ["/Applications/LibreOffice.app/Contents/MacOS/soffice",
              r"C:\Program Files\LibreOffice\program\soffice.exe"]:
        if os.path.exists(p):
            return p
    return None


def run(cmd, timeout=300, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **kw)


def hex_color(rgb):
    return "%02X%02X%02X" % tuple(int(max(0, min(255, c))) for c in rgb[:3])


def contact_sheets(paths, out_prefix: Path, per_sheet=6, cols=2, thumb_w=960):
    """Une varias imágenes en hojas de contacto para revisarlas con pocas vistas."""
    from PIL import Image
    outs = []
    paths = list(paths)
    for k in range(0, len(paths), per_sheet):
        ims = [Image.open(p).convert("RGB") for p in paths[k:k + per_sheet]]
        ims = [im.resize((thumb_w, int(im.height * thumb_w / im.width))) for im in ims]
        rows = (len(ims) + cols - 1) // cols
        rh = max(im.height for im in ims)
        sheet = Image.new("RGB", (cols * thumb_w + (cols - 1) * 12, rows * rh + (rows - 1) * 12), "white")
        for i, im in enumerate(ims):
            sheet.paste(im, ((i % cols) * (thumb_w + 12), (i // cols) * (rh + 12)))
        out = Path(f"{out_prefix}_{k // per_sheet + 1}.png")
        sheet.save(out)
        outs.append(out)
    return outs
