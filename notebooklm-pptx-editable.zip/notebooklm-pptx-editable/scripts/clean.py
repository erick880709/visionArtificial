"""Fase 2a: borra el texto 'quemado' de cada imagen para dejar un fondo limpio
sobre el que se colocarán los cuadros de texto editables."""
from pathlib import Path

import cv2
import numpy as np

from common import log


def _hex_to_rgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.float32)


def _erase_regions(block):
    """Rectángulos a borrar para un bloque: sus líneas (o el bbox si fue editado
    a mano), más los erase_boxes_px explícitos. Si hay viñetas, se extiende a
    la izquierda para borrar también el símbolo dibujado."""
    boxes = block.get("line_boxes_px") or [block["bbox_px"]]
    has_bullets = (any(p.get("bullet") for p in block.get("paragraphs", []))
                   and not block.get("bullet_glyph_in_box"))
    out = []
    for x, y, w, h in boxes:
        if has_bullets:
            ext = 1.8 * h
            x, w = x - ext, w + ext
        out.append(("text", [x, y, w, h]))
    for b in block.get("erase_boxes_px", []):
        out.append(("solid", b))
    return out


def _smooth_fill(region, mask, max_resid=5.0):
    """Ajusta un polinomio 2D de grado 2 a los píxeles de fondo (fuera de la
    máscara). Si el ajuste es bueno, devuelve la predicción para toda la región."""
    h, w = mask.shape
    yy, xx = np.mgrid[0:h, 0:w]
    xs, ys = xx / max(w, 1), yy / max(h, 1)
    A = np.stack([np.ones_like(xs), xs, ys, xs * xs, xs * ys, ys * ys], axis=-1).reshape(-1, 6)
    bgsel = (mask == 0).reshape(-1)
    if bgsel.sum() < 40:
        return None
    pix = region.reshape(-1, 3)
    coef, *_ = np.linalg.lstsq(A[bgsel], pix[bgsel], rcond=None)
    pred = A @ coef
    resid = np.abs(pix[bgsel] - pred[bgsel]).mean(axis=1)
    if np.percentile(resid, 95) > max_resid * 2 or resid.mean() > max_resid:
        return None
    noise = np.random.default_rng(0).normal(0, min(1.0, resid.mean()), pred.shape)
    return (pred + noise).reshape(h, w, 3)


def clean_slide(img_bgr, slide):
    H, W = img_bgr.shape[:2]
    img = img_bgr.copy()
    inpaint_mask = np.zeros((H, W), np.uint8)

    for block in slide["blocks"]:
        if not block.get("remove_from_background", True):
            continue
        tcol = _hex_to_rgb(block.get("color", "000000"))[::-1]   # a BGR
        bcol = _hex_to_rgb(block.get("bg_color", "FFFFFF"))[::-1]
        for kind, (x, y, w, h) in _erase_regions(block):
            lh = max(h, 8)
            pad = 0.25 * lh
            x0, y0 = int(max(0, x - pad)), int(max(0, y - pad))
            x1, y1 = int(min(W, x + w + pad)), int(min(H, y + h + pad))
            region = img[y0:y1, x0:x1].astype(np.float32)
            if region.size == 0:
                continue
            if kind == "solid":
                m = np.ones(region.shape[:2], np.uint8)
            else:
                dt = np.linalg.norm(region - tcol, axis=2)
                db = np.linalg.norm(region - bcol, axis=2)
                contrast = np.linalg.norm(tcol - bcol) + 1e-6
                m = ((dt < db) | (db > 0.12 * contrast)).astype(np.uint8)
                k = max(3, int(0.12 * lh))
                m = cv2.dilate(m, np.ones((2 * k + 1, 2 * k + 1), np.uint8))
            pred = _smooth_fill(region, m)
            if pred is not None:
                # fondo plano o degradado suave: se reconstruye con un modelo
                # polinómico, sin halos ni manchas
                region[m == 1] = pred[m == 1]
                img[y0:y1, x0:x1] = np.clip(region, 0, 255).astype(np.uint8)
            else:
                sub = inpaint_mask[y0:y1, x0:x1]
                np.maximum(sub, m * 255, out=sub)

    if inpaint_mask.any():
        radius = 7
        img = cv2.inpaint(img, inpaint_mask, radius, cv2.INPAINT_TELEA)
    return img


def clean_all(workdir: Path, layout):
    outdir = workdir / "backgrounds"
    outdir.mkdir(exist_ok=True)
    for slide in layout["slides"]:
        src = workdir / slide["image"]
        img = cv2.imread(str(src), cv2.IMREAD_COLOR)
        if slide.get("keep_original_background"):
            cleaned = img
        else:
            cleaned = clean_slide(img, slide)
        out = outdir / f"bg_{slide['index']:02d}.png"
        cv2.imwrite(str(out), cleaned)
        slide["background"] = str(out.relative_to(workdir))
        log(f"slide {slide['index']}: fondo limpio -> {out.name}")
    return layout
