"""Fase 2c: renderiza el PPTX resultante y genera imágenes lado a lado
(original | editable) para la revisión visual."""
from pathlib import Path

from PIL import Image, ImageDraw

from common import find_soffice, log, run


def render_pptx(pptx: Path, outdir: Path):
    soffice = find_soffice()
    if not soffice:
        log("⚠ LibreOffice no está instalado; se omite el render de verificación")
        return []
    outdir.mkdir(parents=True, exist_ok=True)
    profile = (outdir / "lo_profile").resolve().as_uri()
    try:
        run([soffice, f"-env:UserInstallation={profile}", "--headless", "--norestore",
             "--convert-to", "pdf", "--outdir", str(outdir), str(pptx)], timeout=240)
    except Exception as e:
        log(f"⚠ LibreOffice falló o tardó demasiado ({e})")
        return []
    pdf = outdir / (pptx.stem + ".pdf")
    if not pdf.exists():
        log("⚠ no se generó el PDF de verificación")
        return []
    for old in outdir.glob("r-*.png"):
        old.unlink()
    run(["pdftoppm", "-r", "110", "-png", str(pdf), str(outdir / "r")], timeout=300)
    return sorted(outdir.glob("r-*.png"))


def side_by_side(workdir: Path, layout, pptx: Path):
    renders = render_pptx(pptx, workdir / "review" / "render")
    outs = []
    for s, r in zip(layout["slides"], renders):
        a = Image.open(workdir / s["image"]).convert("RGB")
        b = Image.open(r).convert("RGB")
        h = 540
        a = a.resize((int(a.width * h / a.height), h))
        b = b.resize((int(b.width * h / b.height), h))
        canvas = Image.new("RGB", (a.width + b.width + 30, h + 40), "white")
        canvas.paste(a, (0, 40)); canvas.paste(b, (a.width + 30, 40))
        d = ImageDraw.Draw(canvas)
        d.text((10, 12), f"Slide {s['index']} - ORIGINAL (imagen)", fill="black")
        d.text((a.width + 40, 12), "EDITABLE (render LibreOffice)", fill="black")
        out = workdir / "review" / f"compare_{s['index']:02d}.png"
        canvas.save(out)
        outs.append(out)
    if outs:
        from common import contact_sheets
        sheets = contact_sheets(outs, workdir / "review" / "compare_sheet", per_sheet=4, cols=1, thumb_w=1400)
        log(f"comparativas en {outs[0].parent}: compare_NN.png y " + ", ".join(p.name for p in sheets))
    return outs
