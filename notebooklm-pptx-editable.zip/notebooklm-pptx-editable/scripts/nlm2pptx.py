#!/usr/bin/env python3
"""CLI de notebooklm-pptx-editable.

  analyze <archivo.pptx|pdf> [--workdir DIR] [--lang spa,eng] [--font Arial]
      Extrae las imágenes, hace OCR y escribe DIR/layout.json + overlays.

  build <DIR> [--out salida.pptx] [--no-compare]
      Limpia fondos, arma el PPTX editable y genera comparativas.

  all <archivo> [...]   analyze + build sin revisión intermedia (solo borradores).

  doctor                Verifica dependencias (Python, Tesseract, idiomas, LibreOffice).
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from common import default_output_path, load_json, log, resolve_input, save_json  # noqa: E402


def cmd_analyze(a):
    from extract import extract
    from ocr import analyze
    src = resolve_input(a.input)
    workdir = Path(a.workdir) if a.workdir else Path.cwd() / f"{src.stem}_nlm2pptx_work"
    if not _writable(workdir):
        workdir = Path("/tmp") / f"{src.stem}_nlm2pptx_work"
    workdir.mkdir(parents=True, exist_ok=True)
    log(f"entrada: {src}")
    log(f"carpeta de trabajo: {workdir}")
    manifest = extract(src, workdir)
    save_json(manifest, workdir / "manifest.json")
    layout = analyze(workdir, manifest, a.lang.split(","), a.font)
    layout["source"] = str(src)
    layout["output"] = str(Path(a.out).resolve() if a.out else default_output_path(src))
    save_json(layout, workdir / "layout.json")
    log(f"layout listo: {workdir / 'layout.json'}  | overlays en {workdir / 'review'}")
    return workdir


def cmd_build(a, workdir=None):
    from build import build
    from clean import clean_all
    from compare import side_by_side
    workdir = Path(workdir or a.workdir).resolve()
    layout = load_json(workdir / "layout.json")
    out = Path(a.out).resolve() if getattr(a, "out", None) else Path(layout["output"])
    layout = clean_all(workdir, layout)
    save_json(layout, workdir / "layout.json")
    build(workdir, layout, out)
    if not getattr(a, "no_compare", False):
        side_by_side(workdir, layout, out)
    print(f"\nRESULTADO: {out}")


def cmd_doctor(_a):
    import importlib
    import shutil
    ok = True
    for mod, pkg in [("pptx", "python-pptx"), ("cv2", "opencv-python-headless"), ("numpy", "numpy"),
                     ("PIL", "Pillow"), ("lxml", "lxml")]:
        try:
            importlib.import_module(mod); print(f"  ✔ {pkg}")
        except ImportError:
            ok = False; print(f"  ✘ {pkg}  ->  pip install {pkg}")
    if shutil.which("tesseract"):
        from ocr import ensure_tesseract
        print(f"  ✔ tesseract (idiomas usados: {ensure_tesseract(['spa', 'eng'])})")
    else:
        ok = False; print("  ✘ tesseract  ->  ver resources/instalacion.md")
    from common import find_soffice
    print(f"  {'✔' if find_soffice() else '•'} LibreOffice (opcional: render de verificación)")
    print(f"  {'✔' if shutil.which('pdftoppm') else '•'} poppler/pdftoppm (opcional: entrada PDF y verificación)")
    sys.exit(0 if ok else 1)


def _writable(d: Path):
    try:
        d.mkdir(parents=True, exist_ok=True)
        (d / ".w").touch(); (d / ".w").unlink()
        return True
    except OSError:
        return False


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("analyze"); p1.add_argument("input"); p1.add_argument("--workdir")
    p1.add_argument("--lang", default="spa,eng"); p1.add_argument("--font", default="Arial")
    p1.add_argument("--out")
    p2 = sub.add_parser("build"); p2.add_argument("workdir"); p2.add_argument("--out")
    p2.add_argument("--no-compare", action="store_true")
    p3 = sub.add_parser("all"); p3.add_argument("input"); p3.add_argument("--workdir")
    p3.add_argument("--lang", default="spa,eng"); p3.add_argument("--font", default="Arial")
    p3.add_argument("--out"); p3.add_argument("--no-compare", action="store_true")
    sub.add_parser("doctor")
    a = ap.parse_args()
    if a.cmd == "doctor":
        cmd_doctor(a)
    elif a.cmd == "analyze":
        cmd_analyze(a)
    elif a.cmd == "build":
        cmd_build(a)
    else:
        cmd_build(a, cmd_analyze(a))


if __name__ == "__main__":
    main()
