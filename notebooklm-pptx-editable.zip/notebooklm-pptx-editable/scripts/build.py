"""Fase 2b: arma el PPTX editable = fondo limpio + cuadros de texto nativos."""
from copy import deepcopy
from pathlib import Path

from lxml import etree
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Emu, Pt

from common import EMU_PER_PT, log

ALIGN = {"left": PP_ALIGN.LEFT, "center": PP_ALIGN.CENTER,
         "right": PP_ALIGN.RIGHT, "justify": PP_ALIGN.JUSTIFY}

# Ajustes geométricos: el bbox del OCR abarca solo la tinta; el cuadro de texto
# necesita espacio para la caja de línea completa y para fuentes algo más anchas.
TOP_SHIFT_EM = 0.20      # la tinta empieza ~0.2 em por debajo del borde de la caja
WIDTH_SLACK = 0.10       # +10 % de ancho para que no se rompan líneas por sustitución de fuente


def _set_slide_background_image(slide, image_path):
    _, rId = slide.part.get_or_add_image_part(str(image_path))
    cSld = slide._element.find(qn("p:cSld"))
    old = cSld.find(qn("p:bg"))
    if old is not None:
        cSld.remove(old)
    bg = etree.SubElement(cSld, qn("p:bg"))
    cSld.remove(bg)
    cSld.insert(0, bg)
    bgPr = etree.SubElement(bg, qn("p:bgPr"))
    blipFill = etree.SubElement(bgPr, qn("a:blipFill"), dpi="0", rotWithShape="1")
    etree.SubElement(blipFill, qn("a:blip"), {qn("r:embed"): rId})
    etree.SubElement(blipFill, qn("a:srcRect"))
    stretch = etree.SubElement(blipFill, qn("a:stretch"))
    etree.SubElement(stretch, qn("a:fillRect"))
    etree.SubElement(bgPr, qn("a:effectLst"))


def _set_bullet(paragraph, level, size_pt, indent_pt=None, color=None):
    pPr = paragraph._p.get_or_add_pPr()
    indent = int((indent_pt or size_pt * 1.1) * EMU_PER_PT)
    pPr.set("marL", str(indent * (level + 1)))
    pPr.set("indent", str(-indent))
    for tag in ("a:buNone", "a:buChar", "a:buAutoNum"):
        for el in pPr.findall(qn(tag)):
            pPr.remove(el)
    for tag in ("a:buClr", "a:buSzPct", "a:buFont"):
        for el in pPr.findall(qn(tag)):
            pPr.remove(el)
    if color:
        clr = etree.SubElement(pPr, qn("a:buClr"))
        etree.SubElement(clr, qn("a:srgbClr"), val=color.upper())
    etree.SubElement(pPr, qn("a:buSzPct"), val="120000")
    etree.SubElement(pPr, qn("a:buFont"), typeface="Arial")
    return etree.SubElement(pPr, qn("a:buChar"), char="•")


def _style_run(run, block, para, defaults):
    f = run.font
    f.name = para.get("font_family") or block.get("font_family") or defaults.get("font_family", "Arial")
    f.size = Pt(para.get("font_size_pt") or block["font_size_pt"])
    f.bold = bool(para.get("bold", block.get("bold", False)))
    f.italic = bool(para.get("italic", block.get("italic", False)))
    f.color.rgb = RGBColor.from_string((para.get("color") or block.get("color") or "000000").upper())


def _fill_text_frame(tf, block, defaults):
    tf.clear()
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.vertical_anchor = MSO_ANCHOR.TOP
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    size = block["font_size_pt"]
    for i, para in enumerate(block["paragraphs"]):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = ALIGN.get(para.get("align") or block.get("align", "left"), PP_ALIGN.LEFT)
        pitch = block.get("line_pitch_pt")
        p.line_spacing = Pt(pitch) if pitch else 1.0
        gap = para.get("space_before_pt")
        if gap is None and i > 0:
            gap = block.get("paragraph_spacing_pt")
        if gap:
            p.space_before = Pt(gap)
        if para.get("bullet"):
            _set_bullet(p, int(para.get("level", 0)), para.get("font_size_pt") or size,
                        block.get("bullet_indent_pt"),
                        para.get("bullet_color") or block.get("bullet_color"))
        runs = para.get("runs") or [{"text": para["text"]}]
        for rdef in runs:
            r = p.add_run()
            r.text = rdef["text"]
            merged = dict(para)
            merged.update({k: v for k, v in rdef.items() if k != "text"})
            _style_run(r, block, merged, defaults)


def _box_geometry(block, slide, px2emu_x, px2emu_y, sw, sh):
    x, y, w, h = block.get("box_px") or block["bbox_px"]
    size_emu = block["font_size_pt"] * EMU_PER_PT
    left, top = px2emu_x(x), px2emu_y(y)
    width = px2emu_x(x + w) - left
    n_lines = max(1, len(block.get("line_boxes_px") or block["paragraphs"]))
    pitch = (block.get("line_pitch_pt") or block["font_size_pt"] * 1.2) * EMU_PER_PT
    pitch += (block.get("paragraph_spacing_pt") or 0) * EMU_PER_PT
    if not block.get("box_px"):
        top -= int(TOP_SHIFT_EM * size_emu)
        wrapped = any(p.get("wrapped_lines", 1) > 1 for p in block["paragraphs"])
        slack = int(width * (0.03 if wrapped else WIDTH_SLACK)) + int(size_emu * (0.3 if wrapped else 0.5))
        align = block.get("align", "left")
        if align == "center":
            left -= slack // 2
        elif align == "right":
            left -= slack
        width += slack
        height = int(max(px2emu_y(y + h) - px2emu_y(y), n_lines * pitch) + 0.3 * size_emu)
    else:
        height = px2emu_y(y + h) - top
    left = max(0, min(left, sw - 1)); top = max(0, top)
    width = min(width, sw - left)
    return int(left), int(top), int(width), int(height)


def build(workdir: Path, layout, out_path: Path):
    prs = Presentation()
    sw, sh = layout["slide_width_emu"], layout["slide_height_emu"]
    prs.slide_width, prs.slide_height = Emu(sw), Emu(sh)
    title_only = next((l for l in prs.slide_layouts if l.name == "Title Only"), prs.slide_layouts[5])
    defaults = layout.get("defaults", {})

    for s in layout["slides"]:
        slide = prs.slides.add_slide(title_only)
        W, H = s["image_px"]
        pl = s["placement_emu"]
        px2emu_x = lambda v: int(pl[0] + v * pl[2] / W)
        px2emu_y = lambda v: int(pl[1] + v * pl[3] / H)

        bg = workdir / (s.get("background") or s["image"])
        full = abs(pl[2] - sw) < sw * 0.01 and abs(pl[3] - sh) < sh * 0.01
        if full:
            _set_slide_background_image(slide, bg)
        else:
            pic = slide.shapes.add_picture(str(bg), pl[0], pl[1], pl[2], pl[3])
            slide.shapes._spTree.remove(pic._element)
            slide.shapes._spTree.insert(2, pic._element)

        title_ph = slide.shapes.title
        used_title = False
        for n, block in enumerate(s["blocks"], start=1):
            if not block.get("paragraphs") or block.get("skip"):
                continue
            geo = _box_geometry(block, s, px2emu_x, px2emu_y, sw, sh)
            if block.get("role") == "title" and title_ph is not None and not used_title:
                shp = title_ph
                shp.left, shp.top, shp.width, shp.height = geo
                shp.name = "Título"
                used_title = True
            else:
                shp = slide.shapes.add_textbox(*geo)
                shp.name = f"Texto {n}"
            _fill_text_frame(shp.text_frame, block, defaults)
        if title_ph is not None and not used_title:
            title_ph._element.getparent().remove(title_ph._element)

        if s.get("notes"):
            slide.notes_slide.notes_text_frame.text = s["notes"]

    out_path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(out_path))
    log(f"PPTX editable guardado en {out_path}")
    return out_path
