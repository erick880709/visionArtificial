"""Fase 1b: OCR con Tesseract + estimación de estilo (tamaño, color, negrita,
alineación) de cada bloque de texto. Genera layout.json y overlays de revisión."""
import csv
import io
import os
import shutil
import tempfile
import urllib.request
from pathlib import Path
from statistics import median

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from common import EMU_PER_PT, hex_color, log, run

TESSDATA_URL = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/{lang}.traineddata"
# Relación tamaño-de-fuente / alto de línea, calibrada con texto sans-serif.
# alto_bbox_linea(px) ≈ 1.0 * em(px) (con ascendentes+descendentes); paso ≈ 1.2 em
LINE_BOX_TO_EM = 1.0
# Métricas típicas de una sans-serif (en fracciones de em) para normalizar el
# alto de la caja según las letras presentes en la línea.
ASCENDER, XHEIGHT, DESCENDER = 0.76, 0.53, 0.22
_ASC = set("bdfhkltij0123456789áéíóúÁÉÍÓÚñÑ¿¡?!/()[]{}|'\"%&#$@") | set("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
_DESC = set("gjpqyç,;()[]{}|")


def line_em_px(text, h):
    top = ASCENDER if any(c in _ASC for c in text) else XHEIGHT
    bottom = DESCENDER if any(c in _DESC for c in text) else 0.0
    return h / (top + bottom)


# ---------------------------------------------------------------- Tesseract
def ensure_tesseract(langs):
    if not shutil.which("tesseract"):
        raise SystemExit(
            "ERROR: falta Tesseract OCR.\n"
            "  Ubuntu/Debian: sudo apt-get install -y tesseract-ocr tesseract-ocr-spa\n"
            "  macOS:         brew install tesseract tesseract-lang\n"
            "  Windows:       winget install UB-Mannheim.TesseractOCR (marca 'Spanish')")
    have = set(run(["tesseract", "--list-langs"]).stdout.split()[1:] or [])
    have |= set(run(["tesseract", "--list-langs"]).stderr.split()[1:] or [])
    missing = [l for l in langs if l not in have]
    if not missing:
        return "+".join(langs)
    # Descarga los idiomas faltantes a una carpeta de usuario.
    cache = Path(os.environ.get("NLM2PPTX_TESSDATA", Path.home() / ".cache" / "nlm2pptx" / "tessdata"))
    cache.mkdir(parents=True, exist_ok=True)
    sysdir = None
    out = run(["tesseract", "--list-langs"])
    first = (out.stdout or out.stderr).splitlines()[0] if (out.stdout or out.stderr) else ""
    if '"' in first:
        sysdir = Path(first.split('"')[1])
    if sysdir and sysdir.is_dir():
        for f in sysdir.glob("*.traineddata"):
            if not (cache / f.name).exists():
                shutil.copy(f, cache / f.name)
    ok = []
    for lang in langs:
        if lang in have:
            ok.append(lang)
            continue
        dest = cache / f"{lang}.traineddata"
        if not dest.exists():
            try:
                log(f"descargando modelo OCR '{lang}'…")
                urllib.request.urlretrieve(TESSDATA_URL.format(lang=lang), dest)
            except Exception as e:  # sin red: seguimos con lo que haya
                log(f"⚠ no se pudo descargar '{lang}' ({e}); se omite")
                continue
        ok.append(lang)
    os.environ["TESSDATA_PREFIX"] = str(cache)
    if not ok:
        ok = ["eng"]
    return "+".join(ok)


def tesseract_words(img: Image.Image, lang: str, scale: float):
    tmp = io.BytesIO()
    img.save(tmp, format="PNG")
    tmp_path = Path(tempfile.gettempdir()) / f"nlm2pptx_ocr_{os.getpid()}.png"
    tmp_path.write_bytes(tmp.getvalue())
    r = run(["tesseract", str(tmp_path), "stdout", "-l", lang, "--psm", "3",
             "-c", "preserve_interword_spaces=1", "-c", "tessedit_create_tsv=1"], timeout=300)
    tmp_path.unlink(missing_ok=True)
    words = []
    for row in csv.DictReader(io.StringIO(r.stdout), delimiter="\t", quoting=csv.QUOTE_NONE):
        try:
            if row["level"] != "5":
                continue
            text = (row.get("text") or "").strip()
            conf = float(row["conf"])
        except (KeyError, ValueError, TypeError):
            continue
        if not text or conf < 0:
            continue
        # ruido típico de ilustraciones: tokens cortos, sin letras y de baja confianza
        if conf < 45 and (len(text) <= 2 or not any(c.isalnum() for c in text)):
            continue
        x, y, w, h = (int(row[k]) / scale for k in ("left", "top", "width", "height"))
        words.append({"block": int(row["block_num"]), "par": int(row["par_num"]),
                      "line": int(row["line_num"]), "text": text, "conf": conf,
                      "x": x, "y": y, "w": w, "h": h})
    return words


# ---------------------------------------------------------------- agrupación
def _union(boxes):
    x0 = min(b[0] for b in boxes); y0 = min(b[1] for b in boxes)
    x1 = max(b[0] + b[2] for b in boxes); y1 = max(b[1] + b[3] for b in boxes)
    return [x0, y0, x1 - x0, y1 - y0]


BULLET_GLYPHS = set("eo•·◦▪■●○*-–—»>©@°«")


def group_lines(words):
    """Agrupa palabras en líneas y parte una línea cuando hay un hueco horizontal
    grande (columnas o tarjetas lado a lado que Tesseract unió)."""
    raw = {}
    for w in words:
        raw.setdefault((w["block"], w["par"], w["line"]), []).append(w)
    out = []
    for ws in raw.values():
        ws.sort(key=lambda w: w["x"])
        hmed = median(w["h"] for w in ws)
        segs, cur = [], [ws[0]]
        for a, b in zip(ws, ws[1:]):
            if b["x"] - (a["x"] + a["w"]) > 1.3 * hmed:
                segs.append(cur); cur = [b]
            else:
                cur.append(b)
        segs.append(cur)
        for seg in segs:
            bullet, text_x = False, None
            if (len(seg) >= 2 and len(seg[0]["text"]) == 1 and seg[0]["text"] in BULLET_GLYPHS
                    and seg[1]["x"] - (seg[0]["x"] + seg[0]["w"]) > 0.5 * hmed):
                bullet, text_x = True, seg[1]["x"]
            text_words = seg[1:] if bullet else seg
            bbox = _union([(w["x"], w["y"], w["w"], w["h"]) for w in seg])
            text_bbox = _union([(w["x"], w["y"], w["w"], w["h"]) for w in text_words])
            out.append({"text": " ".join(w["text"] for w in text_words), "bbox": bbox,
                        "h": text_bbox[3], "bullet": bullet,
                        "bullet_indent_px": (text_x - bbox[0]) if bullet else None,
                        "conf": float(np.mean([w["conf"] for w in seg])),
                        "word_boxes": [[w["x"], w["y"], w["w"], w["h"]] for w in seg]})
    out.sort(key=lambda l: (l["bbox"][1], l["bbox"][0]))
    return out


def split_blocks(lines, img_w):
    """Agrupación geométrica propia: una línea se une al bloque cuya última línea
    tiene tamaño parecido, está alineada (izquierda o centro) y cerca en vertical."""
    blocks = []
    for l in lines:
        x, y, w, h = l["bbox"]
        best = None
        for blk in blocks:
            p = blk[-1]
            px, py, pw, ph = p["bbox"]
            if abs(l["h"] - p["h"]) / max(l["h"], p["h"]) > 0.25:
                continue
            gap = y - (py + ph)
            if gap < -0.3 * h or gap > 1.8 * max(h, ph):
                continue
            same_left = abs(x - px) < 0.02 * img_w
            same_center = abs((x + w / 2) - (px + pw / 2)) < 0.02 * img_w
            overlap = min(x + w, px + pw) - max(x, px) > 0.3 * min(w, pw)
            if (same_left or same_center) and overlap:
                if best is None or py > best[-1]["bbox"][1]:
                    best = blk
        if best is not None:
            best.append(l)
        else:
            blocks.append([l])
    return blocks


# ---------------------------------------------------------------- estilo
def text_and_bg_colors(arr, boxes):
    pix = []
    for x, y, w, h in boxes:
        x0, y0 = max(0, int(x)), max(0, int(y))
        crop = arr[y0:int(y + h), x0:int(x + w)]
        if crop.size:
            pix.append(crop.reshape(-1, 3))
    if not pix:
        return (0, 0, 0), (255, 255, 255)
    data = np.concatenate(pix).astype(np.float32)
    if len(data) > 40000:
        data = data[np.random.default_rng(0).choice(len(data), 40000, replace=False)]
    _, labels, centers = cv2.kmeans(data, 2, None,
                                    (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 0.5),
                                    3, cv2.KMEANS_PP_CENTERS)
    counts = np.bincount(labels.flatten(), minlength=2)
    t, b = (0, 1) if counts[0] < counts[1] else (1, 0)
    # el centro del clúster de texto se aclara por el antialiasing: tomamos el
    # percentil más alejado del fondo dentro del clúster
    tpix = data[labels.flatten() == t]
    bg = centers[b]
    d = np.linalg.norm(tpix - bg, axis=1)
    core = tpix[d >= np.percentile(d, 60)] if len(tpix) > 10 else tpix
    return tuple(np.median(core, axis=0)), tuple(bg)


def stroke_ratio(arr, boxes, tcol, bcol):
    """Grosor de trazo relativo al alto de línea (≈0.09 normal, ≥0.12 negrita)."""
    ratios = []
    t, b = np.array(tcol), np.array(bcol)
    for x, y, w, h in boxes:
        crop = arr[max(0, int(y)):int(y + h), max(0, int(x)):int(x + w)].astype(np.float32)
        if crop.size == 0 or h < 6:
            continue
        mask = (np.linalg.norm(crop - t, axis=2) < np.linalg.norm(crop - b, axis=2)).astype(np.uint8)
        if mask.sum() < 20:
            continue
        dist = cv2.distanceTransform(mask, cv2.DIST_L2, 3)
        local_max = (dist == cv2.dilate(dist, np.ones((3, 3)))) & (dist > 0)
        sw = 2 * float(np.median(dist[local_max])) if local_max.any() else 0
        ratios.append(sw / h)
    return float(np.median(ratios)) if ratios else 0.0


def guess_align(line_boxes, img_w):
    lefts = [b[0] for b in line_boxes]
    centers = [b[0] + b[2] / 2 for b in line_boxes]
    rights = [b[0] + b[2] for b in line_boxes]
    if len(line_boxes) >= 2:
        s = {"left": np.std(lefts), "center": np.std(centers), "right": np.std(rights)}
        best = min(s, key=s.get)
        if s[best] < 0.01 * img_w:
            return best
    c = np.mean(centers)
    if abs(c - img_w / 2) < 0.015 * img_w:
        return "center"
    return "left"


def estimate_font_px(lines):
    """Devuelve (em_px, interlineado_px | None, espacio_entre_parrafos_px | None).
    Un paso vertical > 1.5 em indica párrafos/viñetas separados, no líneas
    de un mismo párrafo."""
    est = median(line_em_px(l["text"], l["h"]) for l in lines) * LINE_BOX_TO_EM
    if len(lines) < 2:
        return est, None, None
    tops = sorted(l["bbox"][1] for l in lines)
    pitch = median([b - a for a, b in zip(tops, tops[1:])])
    if pitch / est > 1.55:
        return est, None, pitch - 1.2 * est
    return est, pitch, None


# ---------------------------------------------------------------- principal
def analyze_slide(img_path: Path, entry, manifest, lang, defaults):
    img = Image.open(img_path).convert("RGB")
    W, H = img.size
    scale = 2.0 if W < 1600 else 1.0
    ocr_img = img.resize((int(W * scale), int(H * scale)), Image.LANCZOS) if scale != 1 else img
    words = tesseract_words(ocr_img, lang, scale)
    arr = np.asarray(img)

    # px -> pt: el slide mide slide_height_emu; la imagen ocupa placement_emu
    pl = entry["placement_emu"]
    pt_per_px = (pl[3] / EMU_PER_PT) / H

    blocks = []
    for i, ls in enumerate(split_blocks(group_lines(words), W) if words else [], start=1):
        line_boxes = [l["bbox"] for l in ls]
        word_boxes = [wb for l in ls for wb in l["word_boxes"]]
        tcol, bcol = text_and_bg_colors(arr, word_boxes)
        font_px, pitch_px, para_gap_px = estimate_font_px(ls)
        sr = stroke_ratio(arr, line_boxes, tcol, bcol)
        conf = float(np.mean([l["conf"] for l in ls]))
        paragraphs = []
        for l in ls:
            prev = paragraphs[-1] if paragraphs else None
            # línea que continúa la anterior (ajuste de línea del original):
            # se une al mismo párrafo para que el texto fluya al editarlo
            if (prev is not None and not l["bullet"] and pitch_px
                    and (l["text"][:1].islower() or not prev["text"].rstrip().endswith((".", ":", "!", "?")))):
                prev["text"] = prev["text"].rstrip() + " " + l["text"]
                prev["wrapped_lines"] = prev.get("wrapped_lines", 1) + 1
                continue
            p = {"text": l["text"]}
            if l["bullet"]:
                p["bullet"] = True
            paragraphs.append(p)
        blk = {
            "id": f"s{entry['index']}b{i}",
            "role": "body",
            "bbox_px": [round(v, 1) for v in _union(line_boxes)],
            "line_boxes_px": [[round(v, 1) for v in b] for b in line_boxes],
            "paragraphs": paragraphs,
            "font_size_pt": round(font_px * pt_per_px * 2) / 2,
            "line_pitch_pt": round(pitch_px * pt_per_px, 1) if pitch_px else None,
            "paragraph_spacing_pt": round(para_gap_px * pt_per_px, 1) if para_gap_px else None,
            "color": hex_color(tcol),
            "bg_color": hex_color(bcol),
            "bold": sr >= 0.14,
            "italic": False,
            "align": guess_align(line_boxes, W),
            "ocr_conf": round(conf, 1),
            "stroke_ratio": round(sr, 3),
            "remove_from_background": True,
        }
        indents = [l["bullet_indent_px"] for l in ls if l["bullet"]]
        if indents:
            glyphs = [l["word_boxes"][0] for l in ls if l["bullet"]]
            gp = np.concatenate([arr[int(y):int(y + h), int(x):int(x + w)].reshape(-1, 3)
                                 for x, y, w, h in glyphs]).astype(np.float32)
            d = np.linalg.norm(gp - np.array(bcol, dtype=np.float32), axis=1)
            blk["bullet_color"] = hex_color(np.median(gp[d >= 0.6 * d.max()], axis=0))
            blk["bullet_indent_pt"] = round(median(indents) * pt_per_px, 1)
            blk["bullet_glyph_in_box"] = True
        blocks.append(blk)
    harmonize_sizes(blocks)
    # orden de lectura: por franjas horizontales y luego de izquierda a derecha
    band = 0.06 * H
    blocks.sort(key=lambda b: (round(b["bbox_px"][1] / band), b["bbox_px"][0]))
    for n, b in enumerate(blocks, start=1):
        b["id"] = f"s{entry['index']}b{n}"
    if blocks:
        top = max(blocks, key=lambda b: (b["font_size_pt"], -b["bbox_px"][1]))
        if top["bbox_px"][1] < 0.45 * H:
            top["role"] = "title"
    return {"index": entry["index"], "image": entry["image"], "image_px": [W, H],
            "notes": entry.get("notes", ""), "blocks": blocks}


def harmonize_sizes(blocks):
    """Unifica tamaños casi iguales (±12 %) del mismo color y peso: en el
    original son el mismo estilo; el OCR solo introduce ruido."""
    groups = []
    for b in sorted(blocks, key=lambda b: b["font_size_pt"]):
        for g in groups:
            ref = g[0]
            if (ref["color"] == b["color"] or _close(ref["color"], b["color"])) and ref["bold"] == b["bold"] \
                    and abs(b["font_size_pt"] - ref["font_size_pt"]) / ref["font_size_pt"] <= 0.12:
                g.append(b); break
        else:
            groups.append([b])
    for g in groups:
        if len(g) > 1:
            m = round(median(b["font_size_pt"] for b in g) * 2) / 2
            for b in g:
                b["font_size_pt"] = m


def _close(h1, h2, tol=40):
    a = [int(h1[i:i + 2], 16) for i in (0, 2, 4)]
    b = [int(h2[i:i + 2], 16) for i in (0, 2, 4)]
    return sum(abs(x - y) for x, y in zip(a, b)) < tol


def draw_overlay(workdir: Path, slide):
    img = Image.open(workdir / slide["image"]).convert("RGB")
    d = ImageDraw.Draw(img)
    try:
        f = ImageFont.truetype("DejaVuSans-Bold.ttf", max(14, img.size[1] // 50))
    except OSError:
        f = ImageFont.load_default()
    for b in slide["blocks"]:
        x, y, w, h = b["bbox_px"]
        col = (255, 0, 80) if b["ocr_conf"] < 70 else (0, 170, 255)
        d.rectangle([x, y, x + w, y + h], outline=col, width=3)
        label = f"{b['id']} {b['font_size_pt']}pt{' B' if b['bold'] else ''}"
        d.rectangle([x, max(0, y - 22), x + 9 * len(label) + 8, y], fill=col)
        d.text((x + 4, max(0, y - 21)), label, fill="white", font=f)
    out = workdir / "review" / f"overlay_{slide['index']:02d}.png"
    out.parent.mkdir(exist_ok=True)
    img.save(out)
    return out


def analyze(workdir: Path, manifest, langs=("spa", "eng"), font_family="Arial"):
    lang = ensure_tesseract(list(langs))
    log(f"OCR con idiomas: {lang}")
    defaults = {"font_family": font_family}
    layout = {"defaults": defaults,
              "slide_width_emu": manifest["slide_width_emu"],
              "slide_height_emu": manifest["slide_height_emu"],
              "slides": []}
    for entry in manifest["slides"]:
        s = analyze_slide(workdir / entry["image"], entry, manifest, lang, defaults)
        s["placement_emu"] = entry["placement_emu"]
        layout["slides"].append(s)
        draw_overlay(workdir, s)
        low = sum(1 for b in s["blocks"] if b["ocr_conf"] < 70)
        log(f"slide {s['index']}: {len(s['blocks'])} bloques de texto" + (f" ({low} con baja confianza)" if low else ""))
    from common import contact_sheets
    sheets = contact_sheets(sorted((workdir / "review").glob("overlay_*.png")),
                            workdir / "review" / "overlays_sheet")
    log("hojas de revisión: " + ", ".join(p.name for p in sheets))
    return layout
