# DevTools Installer (Windows 10/11)

Herramientas: WSL 2 + Ubuntu, Git + Git Bash, Python 3.12, AWS CLI v2, AWS SAM CLI,
kubectl, Insomnia, Kiro, tfenv + Terraform, AgentCore CLI.

## Uso (siempre como Administrador)

| Escenario | Archivo |
|---|---|
| Máquina con internet | `instalar-online.bat` |
| Preparar paquete para otras máquinas | `1-descargar-paquete-offline.bat` → genera `devtools-offline.zip` |
| Máquina sin internet | descomprimir el zip → `2-instalar-offline.bat` |

Parámetros extra (se pasan a cualquier .bat):

    instalar-online.bat -Only git,tfenv,awscli
    instalar-online.bat -Skip wsl,kiro
    instalar-online.bat -PythonVersion 3.13 -TerraformVersion 1.9.8

Claves: wsl, git, python, awscli, sam, kubectl, insomnia, kiro, tfenv, agentcore

## Notas
- WSL requiere reinicio y virtualización habilitada en BIOS.
- tfenv es un script bash: se usa desde **Git Bash** (o se instala aparte dentro de WSL).
  Se instala en el perfil de quien ejecuta el script: si elevas con otra cuenta (admin
  corporativo), quedará en el perfil de esa cuenta.
- AgentCore CLI se instala con pip (`bedrock-agentcore-starter-toolkit`, comando `agentcore`);
  en modo Download necesita Python en la máquina que descarga.
- Si un paquete falla, el resumen final muestra el error y el link de descarga manual.
- Cada ejecución deja un log `setup-YYYYMMDD-HHMMSS.log`.
