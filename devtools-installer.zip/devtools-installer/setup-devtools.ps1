#Requires -Version 5.1
<#
.SYNOPSIS
  Instalador de herramientas de desarrollo: WSL, Git + Git Bash, Python, AWS CLI, AWS SAM CLI,
  kubectl, Insomnia, Kiro, tfenv (+ Terraform) y AgentCore CLI.

.EXAMPLE  .\setup-devtools.ps1                          # Instala todo desde internet (winget)
.EXAMPLE  .\setup-devtools.ps1 -Mode Download -Zip      # Descarga instaladores a .\paquetes y genera zip offline
.EXAMPLE  .\setup-devtools.ps1 -Mode Offline            # Instala desde .\paquetes sin internet
.EXAMPLE  .\setup-devtools.ps1 -Only git,tfenv          # Solo algunas herramientas
.EXAMPLE  .\setup-devtools.ps1 -Skip wsl,kiro           # Todas menos algunas

  Claves válidas: wsl, git, python, awscli, sam, kubectl, insomnia, kiro, tfenv, agentcore
#>
[CmdletBinding()]
param(
    [ValidateSet('Install', 'Download', 'Offline')]
    [string]$Mode = 'Install',
    [string]$PackagesDir = (Join-Path $PSScriptRoot 'paquetes'),
    [string[]]$Only,
    [string[]]$Skip,
    [string]$PythonVersion = '3.12',
    [string]$TerraformVersion = 'latest',
    [switch]$Zip
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'   # Invoke-WebRequest mucho más rápido
$script:NeedsReboot    = $false

# ---------------------------------------------------------------- utilidades
function Write-Step($m) { Write-Host "`n==> $m" -ForegroundColor Cyan }
function Write-Ok($m)   { Write-Host "    [OK] $m" -ForegroundColor Green }
function Write-Bad($m)  { Write-Host "    [!]  $m" -ForegroundColor Yellow }

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Update-SessionPath {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' +
                [Environment]::GetEnvironmentVariable('Path', 'User')
}

function Add-UserPath([string]$Dir) {
    $cur = [Environment]::GetEnvironmentVariable('Path', 'User')
    if (-not $cur) { $cur = '' }
    if (($cur -split ';') -notcontains $Dir) {
        [Environment]::SetEnvironmentVariable('Path', ($cur.TrimEnd(';') + ';' + $Dir).TrimStart(';'), 'User')
    }
    Update-SessionPath
}

function Get-PkgDir([string]$Key) {
    $d = Join-Path $PackagesDir $Key
    New-Item -ItemType Directory -Force -Path $d | Out-Null
    $d
}

# 0x8A15002B = sin actualización aplicable / 0x8A150061 = ya instalado
$WingetOkCodes = @(0, -1978335189, -1978335135)

function Invoke-Winget([string]$Id) {
    $wgArgs = @('install', '--id', $Id, '-e', '--silent', '--disable-interactivity',
                '--accept-package-agreements', '--accept-source-agreements')
    & winget @wgArgs
    if ($WingetOkCodes -notcontains $LASTEXITCODE) { throw "winget install devolvió $LASTEXITCODE para $Id" }
}

function Save-Winget([string]$Id, [string]$Key) {
    $dest = Get-PkgDir $Key
    & winget download --id $Id -e -d $dest --disable-interactivity --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw "winget download devolvió $LASTEXITCODE para $Id" }
}

function Get-Installer([string]$Key) {
    $dir = Join-Path $PackagesDir $Key
    $f = Get-ChildItem $dir -File -ErrorAction SilentlyContinue |
         Where-Object { $_.Extension -in '.msi', '.exe', '.msix', '.msixbundle' } |
         Select-Object -First 1
    if (-not $f) { throw "No hay instalador en $dir. Ejecuta primero -Mode Download." }
    $f.FullName
}

function Install-Local([string]$File, [string]$ExeArgs) {
    switch ([IO.Path]::GetExtension($File).ToLower()) {
        '.msi' { $p = Start-Process msiexec.exe -ArgumentList "/i `"$File`" /qn /norestart" -Wait -PassThru }
        '.exe' {
            if ($ExeArgs) { $p = Start-Process $File -ArgumentList $ExeArgs -Wait -PassThru }
            else          { $p = Start-Process $File -Wait -PassThru }
        }
        { $_ -in '.msix', '.msixbundle' } { Add-AppxPackage -Path $File; return }
        default { throw "Tipo de instalador no soportado: $File" }
    }
    if ($p.ExitCode -notin 0, 3010) { throw "$File terminó con código $($p.ExitCode)" }
    if ($p.ExitCode -eq 3010) { $script:NeedsReboot = $true }
}

function Get-Py {
    Update-SessionPath
    if (Get-Command py -ErrorAction SilentlyContinue)     { return 'py' }
    if (Get-Command python -ErrorAction SilentlyContinue) { return 'python' }
    throw 'Python no está disponible. Instala primero "python".'
}

function Resolve-TerraformVersion {
    if ($TerraformVersion -ne 'latest') { return $TerraformVersion }
    (Invoke-RestMethod 'https://checkpoint-api.hashicorp.com/v1/check/terraform' -UseBasicParsing).current_version
}

# ---------------------------------------------------------------- catálogo (orden = orden de instalación)
$Tools = [ordered]@{
    wsl       = @{ Name = 'WSL 2 + Ubuntu' }
    git       = @{ Name = 'Git + Git Bash';     Id = 'Git.Git';
                   Args = '/VERYSILENT /NORESTART /NOCANCEL /SP- /COMPONENTS="icons,ext\reg\shellhere,gitlfs,assoc,assoc_sh"' }
    python    = @{ Name = "Python $PythonVersion"; Id = "Python.Python.$PythonVersion";
                   Args = '/quiet InstallAllUsers=1 PrependPath=1 Include_pip=1 Include_launcher=1' }
    awscli    = @{ Name = 'AWS CLI v2';         Id = 'Amazon.AWSCLI' }
    sam       = @{ Name = 'AWS SAM CLI';        Id = 'Amazon.SAM-CLI' }
    kubectl   = @{ Name = 'kubectl';            Id = 'Kubernetes.kubectl' }
    insomnia  = @{ Name = 'Insomnia';           Id = 'Kong.Insomnia'; Args = '/S --silent';
                   Manual = 'https://insomnia.rest/download' }
    kiro      = @{ Name = 'Kiro';               Id = 'Amazon.Kiro';
                   Args = '/VERYSILENT /NORESTART /MERGETASKS=!runcode,addtopath';
                   Manual = 'https://kiro.dev/downloads  (deja el .exe en paquetes\kiro)' }
    tfenv     = @{ Name = 'tfenv + Terraform' }
    agentcore = @{ Name = 'AgentCore CLI (bedrock-agentcore-starter-toolkit)' }
}

# ---------------------------------------------------------------- herramientas con lógica propia
$Custom = @{

    wsl = {
        param($Mode)
        switch ($Mode) {
            'Install' {
                & wsl.exe --install -d Ubuntu --no-launch
                if ($LASTEXITCODE -ne 0) { throw "wsl --install devolvió $LASTEXITCODE" }
                $script:NeedsReboot = $true
            }
            'Download' {
                Save-Winget 'Microsoft.WSL' 'wsl'
                $dir = Get-PkgDir 'wsl'
                Invoke-WebRequest 'https://aka.ms/wslubuntu2204' -OutFile (Join-Path $dir 'Ubuntu2204.appxbundle') -UseBasicParsing
            }
            'Offline' {
                dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart | Out-Null
                dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart | Out-Null
                $dir = Join-Path $PackagesDir 'wsl'
                $msi = Get-ChildItem $dir -Filter *.msi -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($msi) { Install-Local $msi.FullName '' }
                $distro = Get-ChildItem $dir -Filter 'Ubuntu*' -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($distro) { Add-AppxPackage -Path $distro.FullName }
                $script:NeedsReboot = $true
            }
        }
    }

    kubectl = {
        param($Mode)
        switch ($Mode) {
            'Install'  { Invoke-Winget 'Kubernetes.kubectl' }
            'Download' { Save-Winget 'Kubernetes.kubectl' 'kubectl' }
            'Offline'  {
                $exe = Get-ChildItem (Join-Path $PackagesDir 'kubectl') -Filter 'kubectl*.exe' | Select-Object -First 1
                if (-not $exe) { throw 'No se encontró kubectl.exe en paquetes\kubectl' }
                $bin = 'C:\Tools\bin'
                New-Item -ItemType Directory -Force -Path $bin | Out-Null
                Copy-Item $exe.FullName (Join-Path $bin 'kubectl.exe') -Force
                Add-UserPath $bin
            }
        }
    }

    tfenv = {
        param($Mode)
        $root = Join-Path $env:USERPROFILE '.tfenv'
        $dir  = Join-Path $PackagesDir 'tfenv'
        switch ($Mode) {
            'Install' {
                Update-SessionPath
                if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'tfenv requiere Git; instala "git" primero.' }
                if (Test-Path (Join-Path $root '.git')) { git -C $root pull --quiet }
                else { git clone --depth 1 https://github.com/tfutils/tfenv.git $root }
                if ($LASTEXITCODE -ne 0) { throw 'git clone de tfenv falló' }
                Add-UserPath (Join-Path $root 'bin')
                $bash = Join-Path $env:ProgramFiles 'Git\bin\bash.exe'
                if (Test-Path $bash) {
                    & $bash -lc "tfenv install $TerraformVersion && tfenv use $TerraformVersion"
                    if ($LASTEXITCODE -ne 0) { throw 'tfenv install terraform falló' }
                }
            }
            'Download' {
                $dir = Get-PkgDir 'tfenv'
                Invoke-WebRequest 'https://github.com/tfutils/tfenv/archive/refs/heads/master.zip' `
                    -OutFile (Join-Path $dir 'tfenv.zip') -UseBasicParsing
                $ver = Resolve-TerraformVersion
                Invoke-WebRequest "https://releases.hashicorp.com/terraform/$ver/terraform_${ver}_windows_amd64.zip" `
                    -OutFile (Join-Path $dir "terraform_${ver}_windows_amd64.zip") -UseBasicParsing
            }
            'Offline' {
                if (-not (Test-Path $root)) {
                    $tmp = Join-Path $env:TEMP 'tfenv-extract'
                    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
                    Expand-Archive (Join-Path $dir 'tfenv.zip') $tmp -Force
                    Move-Item (Get-ChildItem $tmp -Directory | Select-Object -First 1).FullName $root
                }
                Add-UserPath (Join-Path $root 'bin')
                $tfZip = Get-ChildItem $dir -Filter 'terraform_*_windows_amd64.zip' | Select-Object -First 1
                if ($tfZip) {
                    $ver  = ($tfZip.BaseName -split '_')[1]
                    $vdir = Join-Path $root "versions\$ver"
                    New-Item -ItemType Directory -Force -Path $vdir | Out-Null
                    Expand-Archive $tfZip.FullName $vdir -Force
                    Set-Content -Path (Join-Path $root 'version') -Value $ver -NoNewline -Encoding Ascii
                }
            }
        }
    }

    agentcore = {
        param($Mode)
        $pkg = 'bedrock-agentcore-starter-toolkit'
        $py  = Get-Py
        switch ($Mode) {
            'Install'  { & $py -m pip install --upgrade pip $pkg }
            'Download' { & $py -m pip download $pkg -d (Get-PkgDir 'agentcore') }
            'Offline'  { & $py -m pip install --no-index --find-links (Join-Path $PackagesDir 'agentcore') $pkg }
        }
        if ($LASTEXITCODE -ne 0) { throw "pip devolvió $LASTEXITCODE" }
    }
}

# ---------------------------------------------------------------- ejecución
if (-not (Test-Admin)) {
    Write-Bad 'Ejecuta este script como Administrador (clic derecho > Ejecutar como administrador).'
    exit 1
}
if ($Mode -ne 'Offline' -and -not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Write-Bad 'winget no está disponible. Instala "App Installer" desde Microsoft Store o usa -Mode Offline.'
    exit 1
}

New-Item -ItemType Directory -Force -Path $PackagesDir | Out-Null
$LogFile = Join-Path $PSScriptRoot ('setup-{0:yyyyMMdd-HHmmss}.log' -f (Get-Date))
Start-Transcript -Path $LogFile | Out-Null

$selected = @($Tools.Keys | Where-Object { (-not $Only -or $_ -in $Only) -and ($_ -notin $Skip) })
$results  = @()

foreach ($key in $selected) {
    $t = $Tools[$key]
    Write-Step "$($t.Name)  [$Mode]"
    try {
        if ($Custom.ContainsKey($key)) {
            & $Custom[$key] $Mode
        } else {
            switch ($Mode) {
                'Install'  { Invoke-Winget $t.Id }
                'Download' { Save-Winget $t.Id $key }
                'Offline'  { Install-Local (Get-Installer $key) $t.Args }
            }
        }
        Update-SessionPath
        $results += [pscustomobject]@{ Herramienta = $t.Name; Estado = 'OK'; Detalle = '' }
        Write-Ok $t.Name
    } catch {
        $msg = $_.Exception.Message
        if ($t.Manual) { $msg += "  -> Descarga manual: $($t.Manual)" }
        $results += [pscustomobject]@{ Herramienta = $t.Name; Estado = 'ERROR'; Detalle = $msg }
        Write-Bad $msg
    }
}

# ---------------------------------------------------------------- verificación
if ($Mode -ne 'Download') {
    Write-Step 'Verificando versiones'
    Update-SessionPath
    $checks = [ordered]@{
        git = 'git --version'; python = 'py --version'; awscli = 'aws --version'; sam = 'sam --version'
        kubectl = 'kubectl version --client'; agentcore = 'agentcore --version'; wsl = 'wsl --version'
    }
    foreach ($k in $checks.Keys) {
        if ($k -notin $selected) { continue }
        $out = (cmd /c "$($checks[$k]) 2>&1" | Select-Object -First 1) -replace "`0", ''
        Write-Host ("    {0,-10} {1}" -f $k, $out)
    }
    if ('tfenv' -in $selected) {
        Write-Host '    tfenv      usar desde Git Bash o WSL:  tfenv list / terraform -version'
    }
}

if ($Mode -eq 'Download' -and $Zip) {
    Write-Step 'Generando zip offline'
    $zipPath = Join-Path $PSScriptRoot 'devtools-offline.zip'
    Remove-Item $zipPath -ErrorAction SilentlyContinue
    $items = Get-ChildItem $PSScriptRoot | Where-Object { $_.Name -notlike '*.log' -and $_.Name -ne 'devtools-offline.zip' }
    Compress-Archive -Path $items.FullName -DestinationPath $zipPath -CompressionLevel Optimal
    Write-Ok "Zip generado: $zipPath"
}

Write-Step 'Resumen'
$results | Format-Table -AutoSize -Wrap
if ($script:NeedsReboot) { Write-Bad 'Reinicia el equipo para completar la instalación de WSL.' }
Write-Host "Log: $LogFile"
Stop-Transcript | Out-Null
