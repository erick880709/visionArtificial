@echo off
net session >nul 2>&1 || (echo Ejecuta este archivo como Administrador & pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-devtools.ps1" -Mode Offline %*
pause
