# Kit IA — de RFP a código funcionando

`kit-ia` **no es una aplicación**: no tiene código fuente, manifiesto de
dependencias, build ni tests propios. Es un kit de **skills de Claude Code**
(`.claude/skills/`) que implementa un pipeline de entrega de software
asistido por IA — desde un documento de RFP hasta un scaffold de código
funcionando en el repositorio del cliente.

`resources/` es el estado compartido, basado en archivos, que cada skill lee
y sobre el que escribe a medida que el trabajo avanza por el pipeline.

Todo lo que producen las skills se escribe **en español** por convención,
sin importar el idioma del documento fuente (términos técnicos como
"API"/"SLA" se mantienen en inglés cuando así lo usa la industria).

## Requisitos

- [Claude Code](https://docs.claude.com/claude-code) (CLI, extensión de IDE o app).
- Opcional pero recomendado: un servidor **MCP de Jira** (Atlassian MCP o
  compatible) conectado a la sesión — habilita `epicureo`, `specter` y
  `builder` para leer/crear directamente issues de Jira. Sin él, esas mismas
  skills funcionan igual pero contra archivos Markdown en `resources/`.
- El proyecto **destino** (donde se genera el código) puede ser cualquier
  lenguaje/stack — `builder` detecta el ecosistema real del repo, no asume uno.

## Cómo usar este kit en un proyecto

`kit-ia` se usa **copiando `.claude/skills/` (y opcionalmente `resources/`)
a la raíz del repositorio destino** — el proyecto real donde se va a construir
la feature. Las skills de Claude Code se resuelven por convención desde
`.claude/skills/` del directorio de trabajo actual, así que el kit viaja con
el proyecto, no al revés.

```bash
# Desde la raíz del repo destino:
cp -r /ruta/a/kit-ia/.claude/skills ./.claude/skills
mkdir -p resources   # las subcarpetas las crea cada skill la primera vez que las necesita
```

A partir de ahí, cada skill se invoca desde una sesión normal de Claude Code
en ese repo (`/janus`, `/epicureo`, `/specter`, `/archi`, `/builder`, `/ranger`,
o simplemente describiendo la necesidad en lenguaje natural — cada skill
declara en su propio `SKILL.md` cuándo debe activarse).

## El pipeline

| Etapa | Skill | Entrada | Salida |
|---|---|---|---|
| 1. Extracción | `janus` | Documento de RFP (PDF/DOCX/PPTX/XLSX/HTML/TXT/MD) | Un `.md` por requerimiento en `resources/functional/requests/` (RF-###), `resources/architecture/definitions/` (RNF-###/RT-###), `resources/design/models/` (RD-###), más `resources/summary/executive-summary.md` |
| 2. Refinamiento | `epicureo` | Necesidad en texto libre, o un RF/RNF/RT de `janus` | `resources/functional/reqs/NNN-slug.md`, y/o una épica de Jira (vía MCP) — itera hasta que el Índice de Ambigüedad (IA) ≤ 15 |
| 3. Desglose | `specter` | Clave de épica de Jira, o un archivo de `resources/functional/reqs/` | Historias de usuario / tareas técnicas como `resources/functional/hu/hu-##-*.md` / `tt-##-*.md`, y/o issues de Jira (vía MCP) |
| 4. Arquitectura | `archi` | Un spec `.md` de requerimientos (Caso A, greenfield), un repo de código existente (Caso B, AS-IS), o ambos (Caso C, TO-BE) | Documento de arquitectura en `resources/architecture/` (`Documento_Arquitectura_<Proyecto>.md` / `Arquitectura_AS-IS_<Proyecto>.md` / `Arquitectura_TO-BE_<Proyecto>.md`) con C4 niveles 1-3 y diagramas de secuencia embebidos (Mermaid); diagrama de despliegue en `.drawio` con iconografía oficial del proveedor de nube — o, si el proveedor no está definido, comparativo multi-nube AWS/Azure/GCP (tres `.drawio` + `Pricing_<Proyecto>.md` + reporte HTML de costos); en el Caso C además gap analysis y roadmap de migración por fases |
| 5. Scaffold | `builder` | Clave de issue de Jira, o un archivo de `resources/functional/hu/` | Scaffold completo del módulo, detectando lenguaje/framework/ORM/patrón arquitectónico del repo destino e imitando un módulo de referencia real — nunca desde templates fijos |
| 6. QA | `ranger` | Plan de pruebas / runbook en Markdown / codebase | Plan de pruebas (`resources/qa/plans/`) y runbook (`resources/qa/runbooks/`), specs de Playwright/Jest/RTL/MSW, evidencia por caso (video/trace/screenshot) en `resources/qa/<CASE-ID>/<runId>/`, y reporte de ejecución con veredicto GO / GO with known risks / NO-GO en `resources/qa/reports/` (foco React/Next.js, pero el patrón aplica a cualquier stack con adaptación) |

Skills de soporte — `docx`, `pdf`, `pptx`, `xlsx` — son de I/O de documentos
genérico; otras skills (sobre todo `janus`) delegan en ellas cuando el RFP
llega en ese formato.

```
RFP/necesidad                     Jira (opcional)
     │                                 ▲  │
     ▼                                 │  ▼
 ┌───────┐   ┌──────────┐   ┌─────────┐   ┌─────────┐   ┌────────┐
 │ janus │──▶│ epicureo │──▶│ specter │──▶│ builder │──▶│ ranger │
 └───────┘   └──────────┘   └─────────┘   └─────────┘   └────────┘
  extrae        refina         desglosa       genera        planes,
  RF/RNF/RT     hasta IA≤15    en HU/TT       el scaffold    E2E/unit,
                                                 │            veredicto
                                           ┌─────┴─────┐      GO/NO-GO
                                           │   archi   │  (documenta o
                                           └───────────┘  propone arquitectura,
                                                           en paralelo, no bloquea)
```

## Flujo básico, paso a paso

Hay dos puntos de entrada típicos. El pipeline es una cadena de **archivos**,
no de comandos obligatorios: cada skill sabe leer tanto la salida de la
skill anterior como una entrada manual equivalente, así que puedes saltar
etapas si ya tienes esa información resuelta.

### Camino largo — llega una RFP

1. **`janus`**: el cliente envía un PDF/Word de RFP. `janus` lo lee y genera
   un `.md` por cada requerimiento funcional/no funcional/técnico en
   `resources/functional/requests/`, `resources/architecture/definitions/`
   y `resources/design/models/`, más un resumen ejecutivo.
2. **`epicureo`**: se toma uno de esos requerimientos (o cualquier necesidad
   en texto libre) y se refina en rondas de preguntas — el skill calcula un
   **Índice de Ambigüedad (IA)** tras cada respuesta y no cierra hasta que
   IA ≤ 15 (o hasta 4 rondas, marcando lo que quede pendiente). Al cerrar,
   pregunta si guardar como Markdown en `resources/functional/reqs/`, crear
   una épica en Jira, o ambas.
3. **`specter`**: con la épica de Jira (o el `.md` de `epicureo`) como
   entrada, la analiza y la desglosa en historias de usuario y tareas
   técnicas, cada una con criterios de aceptación. Pregunta si subirlas a
   Jira, guardarlas como Markdown en `resources/functional/hu/`, o ambas.
4. **`archi`** *(opcional, en paralelo)*: si el equipo necesita el documento
   de arquitectura formal antes de construir, se corre sobre el spec de
   `epicureo` (Caso A, greenfield) o sobre un repo existente (Caso B, AS-IS;
   Caso C, TO-BE con gap analysis y roadmap si además hay requerimientos
   nuevos) — produce diagramas C4 (niveles 1-3) y de secuencia embebidos en
   Mermaid, más el diagrama de despliegue en `.drawio` con iconografía real
   del proveedor de nube (o comparativo multi-nube con pricing y reporte
   HTML si el proveedor todavía no está definido), todo dentro de
   `resources/architecture/`. No bloquea a `builder`, que puede analizar el
   codebase directamente si `archi` no corrió antes.
5. **`builder`**: se le pasa la clave de una historia/tarea de Jira, o el
   archivo `.md` en `resources/functional/hu/`. Detecta el stack real del
   repo destino (o usa lo que dejó `archi`/una corrida anterior de `builder`
   en `resources/architecture/`), busca un módulo existente como plantilla
   viva, y genera el scaffold completo (modelo, repositorio, servicio,
   controller/rutas, UI si aplica) siguiendo esos mismos patrones — nunca un
   template genérico.
6. **`ranger`**: sobre el módulo recién generado, define el plan de pruebas
   (`resources/qa/plans/`), graba o escribe los tests (unitarios,
   integración, E2E con Playwright/Jest/RTL/MSW), ejecuta la suite en fases
   (smoke → regresión) y organiza la evidencia (video, trace, screenshot)
   por caso en `resources/qa/<CASE-ID>/<runId>/`, cerrando con un reporte de
   ejecución y un veredicto GO / GO with known risks / NO-GO en
   `resources/qa/reports/` para cerrar la historia con confianza.

### Camino corto — ya sabes qué construir

Si la necesidad ya está clara y no viene de una RFP formal, se empieza
directo en el paso 2: se describe la necesidad en texto libre a `epicureo`,
que la refina hasta IA ≤ 15, `specter` la desglosa, `builder` genera el
código y `ranger` lo prueba. `janus` y `archi` son opcionales — entran solo
cuando hay un documento de RFP que extraer o un documento de arquitectura
formal que el proyecto exige.

## Convenciones de `resources/`

`resources/` es estado compartido, no un scratchpad — un archivo que ya
existe ahí es entrada para la siguiente etapa, no una salida descartable.

- **Numeración anti-colisión**: antes de crear un archivo nuevo, listar la
  carpeta destino y continuar la numeración desde el ID más alto existente
  — nunca reiniciar en 1 si ya hay archivos.
- **Prefijos de ID**: `RF-###` requerimiento funcional, `RNF-###` no
  funcional, `RT-###` requisito técnico, `RD-###` información de diseño
  (todos de `janus`); `NNN-slug.md` specs refinados (de `epicureo`);
  `HU-##` / `TT-##` historias de usuario / tareas técnicas (de `specter`).
- **Nombre de archivo**: `{ID}-{slug-corto-en-kebab-case}.md`, slug derivado
  del título, minúsculas, sin tildes, máximo ~6 palabras.
- Las carpetas se crean a demanda por la skill que primero las necesita —
  una `resources/<subcarpeta>` vacía o ausente en un checkout nuevo es
  esperado (ver los `.gitkeep`), no un bug.
- `resources/architecture/overview.md`, `resources/architecture/stack.md`,
  `resources/design/data-model.md` y `resources/design/api.md` son
  documentos vivos que `builder` crea una vez analizando el codebase
  destino y luego mantiene actualizados en cada scaffold nuevo — trátalos
  como la fuente de verdad vigente del stack/convenciones de ese proyecto,
  no los rederives desde cero cada vez.
- `archi` guarda todo bajo esa misma carpeta (`resources/architecture/`),
  pero con nombre de archivo por caso: `Documento_Arquitectura_<Proyecto>.md`
  (Caso A), `Arquitectura_AS-IS_<Proyecto>.md` (Caso B) y
  `Arquitectura_TO-BE_<Proyecto>.md` (Caso C, dejando el AS-IS como
  documento separado) — más `Despliegue_<Proveedor>_<Proyecto>.drawio`,
  `Pricing_<Proyecto>.md` y `Arquitectura_Costos_<Proyecto>.html` cuando
  aplica el modo multi-nube. Son documentos de arquitectura completos por
  corrida, distintos del resumen vivo que mantiene `builder` en
  `overview.md`/`stack.md`.
- `ranger` guarda todo bajo `resources/qa/`: planes en `plans/`, runbooks en
  `runbooks/`, evidencia por caso en `<CASE-ID>/<runId>/`
  (video/trace/screenshot) y reportes de ejecución (con veredicto GO / GO
  with known risks / NO-GO) en `reports/`. Los specs automatizados (`e2e/`,
  `tests/`) no van en `resources/` — siguen viviendo en el código fuente del
  proyecto, como cualquier otro test.

## Integración con Jira / MCP

`epicureo`, `specter` y `builder` pueden leer y escribir issues de Jira
cuando hay un servidor MCP compatible con Atlassian conectado a la sesión;
si no lo hay, las tres caen de vuelta a los archivos Markdown de
`resources/`. No asumas que Jira está disponible — cada skill revisa
primero si las herramientas MCP existen y, si no, ofrece la ruta Markdown.

## Generación paralela backend/frontend en `builder`

Cuando un scaffold de `builder` abarca backend y frontend a la vez, el
contrato de API se congela primero (endpoints, forma de request/response,
códigos de error) **antes** de generar ambas capas — luego se generan en
paralelo, cada una con ese contrato + el spec del recurso + el documento de
arquitectura de esa capa, y se cierra con una pasada de reconciliación que
verifica rutas/nombres de campos/forma de error y paginación contra el
contrato congelado. No se genera una capa, se inspecciona, y luego la otra
— eso anula el propósito de congelar el contrato primero.

## Skills incluidas

| Skill | Rol |
|---|---|
| `janus` | Extrae requerimientos desde documentos de RFP |
| `epicureo` | Refina necesidades ambiguas hasta especificación verificable (IA ≤ 15) |
| `specter` | Desglosa épicas de Jira / specs en historias y tareas técnicas |
| `archi` | Arquitecto de software senior — diseño C4 y de secuencia, diagramas de despliegue multi-nube (AWS/Azure/GCP) con iconografía real y pricing comparativo, ADRs, AS-IS/TO-BE, gap analysis y roadmap de migración |
| `builder` | Scaffold de módulos, agnóstico de lenguaje/framework, imitando el codebase real |
| `ranger` | Ingeniero de QA senior para React/Next.js — planes y runbooks de prueba, grabación y ejecución con Playwright/Jest/RTL/MSW, evidencia en video/trace por caso, y veredicto GO / GO with known risks / NO-GO |
| `docx` / `pdf` / `pptx` / `xlsx` | I/O genérico de documentos ofimáticos, usado como soporte por las anteriores |
| `cronos` | Genera presentaciones HTML con la marca de PersonalSoft — slides a pantalla completa, navegación por teclado, puntero láser y animaciones, listas para presentar en vivo desde cualquier navegador |

Cada una tiene el detalle completo de su comportamiento en su propio
`.claude/skills/<nombre>/SKILL.md` — es la fuente de verdad si algo en este
README y el `SKILL.md` no coinciden.
