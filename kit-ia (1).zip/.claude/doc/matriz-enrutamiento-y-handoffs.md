# Matriz de enrutamiento y handoffs

Esta matriz describe una ruta operable con los skills y agentes realmente instalados. No existe un router general en `.claude/agents/`: la secuencia es una guía para la sesión llamadora. Solution Baseline tiene su propio orquestador; Archi, Builder, Storming y Takumi son agentes directos; y Vulcano dispone de un orquestador limitado a definición y generación local.

## Flujo de referencia

```text
Fuentes / RFP
    │
    ├─ janus ──► requisitos extraídos
    │
    └─ epicureo ──► necesidad refinada
                       │
                       ├─ storming, cuando el dominio lo exige
                       │      └─► modelo, límites, reglas y hotspots
                       │
                       ├─ archi ──► arquitectura aprobada
                       │      ├─► iris, para arquitectura UX
                       │      ├─► solution-baseline, para aplicaciones
                       │      └─► vulcano, para DevOps/IaC/observabilidad
                       │
                       └─ specter ──► backlog Jira

solution-baseline ──► builder / ranger durante el desarrollo posterior
vulcano-orchestrator ──► vulcano ──► vulcano-bob ──► handoff humano ──► vulcano-operador
```

No todos los proyectos comienzan con una RFP ni requieren todos los pasos. Los gates de entrada, no una cadena rígida, determinan qué capacidades aplicar.

## Matriz principal

| Intención | Skill canónica | Agente coordinador disponible | Precondición mínima | Handoff principal |
|---|---|---|---|---|
| Extraer requisitos de RFP | `janus` | Sin agente dedicado; invocación directa | Documento fuente accesible | `epicureo`, `archi`, `iris` o `takumi` según contenido |
| Reducir ambigüedad de una necesidad | `epicureo` | Sin agente dedicado | Necesidad o requisitos de entrada | `storming`, `archi`, `specter` o `effort-estimator` |
| Modelar dominio complejo | `storming` | `storming` | Propósito, alcance, fuentes y participantes conocidos | `archi`, `specter`, `iris` o `ranger` |
| Diseñar arquitectura de sistema | `archi` | `archi` | Gate DR-01 satisfecho mediante EventStorming, paquete equivalente o excepción justificada | `solution-baseline`, `iris` y/o `vulcano` |
| Diseñar arquitectura UX y entregar el sistema de diseño | `iris` | `iris` | Requisitos, procesos, dominio, APIs o evidencia de UI; para el sistema de diseño, evidencia de marca del proyecto | `solution-baseline` (tokens, catálogo y assets congelados) y `builder` |
| Desglosar épica en Jira | `specter` | Sin agente dedicado; requiere MCP Jira | Épica accesible y suficientemente refinada | Desarrollo, `builder`, `ranger`, `effort-estimator` |
| Estimar esfuerzo/costo | `effort-estimator` | Sin agente dedicado | Épica refinada o backlog | Propuesta y planificación |
| Materializar aplicaciones | `solution-baseline` | `solution-baseline-orchestrator` y su célula | Arquitectura aprobada, decisiones materiales cerradas y repositorios identificados | Desarrollo y requisitos para Vulcano |
| Implementar funcionalidad, bug, refactor o integración | `builder` | `builder` | Intención o spec suficiente y repositorio inspeccionado; rigor proporcional al riesgo | Cambio verificado; `ranger` cuando se requiera QA especializado |
| Definir o ejecutar calidad | `ranger` | Sin agente dedicado | Riesgos, criterios o código ejecutable | Gates de entrega |
| Documentar procesos de negocio | `takumi` | `takumi` | Fuentes o entrevistas | Mejora de procesos, `epicureo`, `storming` o automatización posterior |
| Diseñar DevOps/IaC/observabilidad | `vulcano` | `vulcano` o `vulcano-orchestrator` para flujo completo | Arquitectura y evidencia real del repositorio | `vulcano-bob` |
| Generar IaC/CI/CD local | `vulcano-bob` | `vulcano-bob` o `vulcano-orchestrator` | Manifiesto Vulcano completo y consistente | `vulcano-operador` |
| Operar plataformas remotas | `vulcano-operador` | `vulcano-operador`, solo invocación humana | Cierre estricto de Bob, capacidades reales y autorización por acción | Verificación y evidencia operacional |

## Gate de dominio para Archi

`archi` no debe producir arquitectura de detalle sin resolver DR-01. La forma preferida para dominios complejos es `storming`. También puede aceptar un paquete equivalente que cubra actores, eventos, reglas, estados, excepciones, lenguaje y límites, o una excepción explícita para un cambio acotado y de bajo impacto.

Si faltan esos insumos, `archi` devuelve el control al levantamiento de dominio. Si existen hotspots, puede continuar solo en áreas no afectadas y debe conservar las decisiones bloqueadas como pendientes.

## Responsabilidad de Builder

`builder` implementa cambios de aplicación con SDD incremental: descubre el estado
real, especifica comportamiento y aceptación, diseña el cambio local, implementa y
registra evidencia. Acepta issues, archivos o texto; no exige Jira ni una estructura
documental fija. Reutiliza contratos y decisiones existentes y no obliga a recorrer
todos los skills para cada tarea.

Puede usarse mediante el agente de entrada directa
[`builder.agent.md`](../agents/builder.agent.md) o invocando el skill. Ambas entradas
aplican el mismo `SKILL.md`; el agente no constituye una segunda implementación.

La validación del cambio pertenece a Builder aunque exista Ranger. Devuelve las
decisiones arquitectónicas materiales a su responsable y respeta el ownership de
Solution Baseline. La ejecución es secuencial salvo independencia real y delegación
disponible/autorizada; SDD no incorpora un router global ni habilita despliegues.

## Responsabilidad de Solution Baseline

`solution-baseline` comienza después de la arquitectura aprobada. Puede buscar y reutilizar arquetipos, crear un arquetipo reutilizable cuando exista una brecha generalizable o usar una estrategia específica del proyecto. No redefine arquitectura ni absorbe backlog, DevOps, IaC o despliegue.

En multi-repositorio, el agente `solution-baseline-orchestrator` construye un DAG. `architecture-mapper` descubre en solo lectura; `repository-baseline-worker` escribe una unidad con lease; `archetype-curator` trabaja el catálogo separado; `baseline-validator` valida independientemente. La concurrencia se limita a nodos sin ownership compartido y a los límites declarados por el manifest.

## Frontera Vulcano

| Componente | Decide | Escribe localmente | Ejecuta remoto |
|---|---:|---:|---:|
| `vulcano-orchestrator` | No | No directamente | No |
| `vulcano` | Sí | Solo documentación | No |
| `vulcano-bob` | No redecide | Sí, IaC y CI/CD | No por defecto |
| `vulcano-operador` | No redecide | Evidencia/manifiesto operacional | Sí, con autorización y allowlist |

## Responsabilidad de Vulcano Orchestrator

`vulcano-orchestrator` deriva el estado desde los manifiestos existentes, invoca `vulcano` cuando la
definición no está cerrada y habilita `vulcano-bob` solo después del validador de completitud. No crea
un manifiesto adicional, no edita artefactos directamente y no toma decisiones de las fases.

Cuando Bob alcanza cierre estricto, el orquestador termina la entrega local. Si se solicitó operación
remota, presenta el handoff para que el usuario inicie `vulcano-operador`; nunca lo invoca, autoriza ni
opera en su nombre.

## Takumi frente a Storming

`takumi` caracteriza y mejora procesos organizacionales, procedimientos, actas, políticas y documentación ISO/BPM. `storming` descubre comportamiento de dominio para software mediante eventos, comandos, políticas, agregados y bounded contexts. Pueden encadenarse, pero ninguno sustituye al otro.

## Estado de enrutabilidad

La secuencia anterior es válida por los contratos de las skills, pero no está automatizada globalmente. Use el agente dedicado cuando exista y valide cada handoff antes de avanzar. Archi, Storming y Takumi informan la transición y devuelven el control al usuario. `vulcano-orchestrator` es la única excepción en esa cadena: puede invocar Vulcano y Bob, pero se detiene antes del operador. Para baselines, delegue en `solution-baseline-orchestrator`; ese agente no debe seleccionar ni gobernar capacidades ajenas a su dominio.

El router general anterior está eliminado del working tree. Su historia y las condiciones para retirarlo o reconstruirlo están en [Orquestador general retirado](./orquestador-retirado.md).
