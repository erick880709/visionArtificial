# Catálogo reconciliado de skills

Inventario de los 25 directorios presentes en `.claude/skills/`, contrastado con el `name` y la responsabilidad declarados en cada `SKILL.md` al 10 de septiembre de 2026 y actualizado el 14 de septiembre de 2026. Ese día `bancolombia-brand-manual` salió de este repositorio: las skills y agentes de `.claude` deben ser genéricos, su copia idéntica sigue en el proyecto que la usa (`kit-ia-poc-bancolombia`) y la identidad visual de cada proyecto pasa a ser un artefacto del propio proyecto (`resources/design/ux/<proyecto>/03-design-system/`). No existe actualmente un router general instalado; “invocación directa” significa seleccionar la skill por su nombre canónico y ejecutar su propio contrato. Cuando la tabla menciona un agente homónimo, este funciona como una entrada especializada a esa misma skill.

## Descubrimiento, producto y dominio

| Directorio | Nombre canónico | Responsabilidad | Modo de uso vigente |
|---|---|---|---|
| [`janus`](../skills/janus/SKILL.md) | `janus` | Extraer requisitos y contexto desde RFP y documentos de entrada | Invocación directa |
| [`epicureo`](../skills/epicureo/SKILL.md) | `epicureo` | Refinar necesidades hasta un índice de ambigüedad aceptable | Invocación directa |
| [`storming`](../skills/storming/SKILL.md) | `storming` | Descubrir y validar dominio con Big Picture, Process Modelling y Software Design de EventStorming | Agente `storming` o invocación directa |
| [`specter`](../skills/specter/SKILL.md) | `specter` | Desglosar una épica de Jira en historias y tareas mediante MCP | Invocación directa; requiere MCP Jira |
| [`cupido`](../skills/cupido/SKILL.md) | `effort-estimator` | Estimar esfuerzo, cronograma y costo, incluida comparación con aceleración por IA | Invocación directa; carpeta y nombre canónico difieren |
| [`takumi`](../skills/takumi/SKILL.md) | `takumi` | Levantar, documentar y mejorar procesos de negocio | Agente `takumi` o invocación directa |

## Arquitectura, experiencia y materialización

| Directorio | Nombre canónico | Responsabilidad | Modo de uso vigente |
|---|---|---|---|
| [`archi`](../skills/archi/SKILL.md) | `archi` | Diseñar, auditar y evolucionar arquitectura de sistema; exige el gate DR-01 antes de arquitectura de detalle | Agente `archi` o invocación directa |
| [`iris`](../skills/iris/SKILL.md) | `iris` | Crear arquitectura de UX, flujos, pantallas, wireframes y trazabilidad, y entregar el sistema de diseño del proyecto (tokens, catálogo de componentes, assets) listo para construir | Agente `iris` o invocación directa |
| [`solution-baseline`](../skills/solution-baseline/SKILL.md) | `solution-baseline` | Materializar arquitectura aprobada en baselines reproducibles y coordinar multi-repositorio | Declarada y respaldada por cinco agentes especializados |
| [`genesis`](../skills/genesis/SKILL.md) | `genesis` | Alias obsoleto que traduce bootstrap greenfield a `solution-baseline --mode create` | Compatibilidad directa; no usar para solicitudes nuevas |
| [`builder`](../skills/builder/SKILL.md) | `builder` | Implementar, explorar, planificar y reanudar cambios de aplicación mediante SDD incremental y evidencia | Agente `builder` o invocación directa; paquete autocontenido disponible |
| [`ranger`](../skills/ranger/SKILL.md) | `ranger` | Diseñar y ejecutar estrategia de calidad, pruebas y evidencia | Invocación directa |

## DevOps, IaC y operación

| Directorio | Nombre canónico | Responsabilidad | Modo de uso vigente |
|---|---|---|---|
| [`vulcano`](../skills/vulcano/SKILL.md) | `vulcano` | Diseñar y documentar DevSecOps, IaC y observabilidad; no ejecutar | Agente `vulcano`, `vulcano-orchestrator` o invocación directa |
| [`vulcano-bob`](../skills/vulcano-bob/SKILL.md) | `vulcano-bob` | Materializar y validar localmente IaC y CI/CD ya definidos por Vulcano | Agente `vulcano-bob`, `vulcano-orchestrator` o invocación directa tras cierre |
| [`vulcano-operador`](../skills/vulcano-operador/SKILL.md) | `vulcano-operador` | Reconciliar y operar planos remotos con autorización por acción | Agente de invocación humana o skill directa tras cierre estricto de Bob |

`solution-baseline` excluye explícitamente DevOps, IaC y despliegue. Esas responsabilidades pertenecen a la secuencia Vulcano → Vulcano Bob → Vulcano Operador.
`vulcano-orchestrator` coordina las dos primeras skills, pero no es una cuarta skill y nunca invoca al operador.

## Ingeniería y estándares especializados

| Directorio | Nombre canónico | Responsabilidad | Modo de uso vigente |
|---|---|---|---|
| [`az-func-openapi`](../skills/az-func-openapi/SKILL.md) | `az-func-openapi` | Patrones OpenAPI 3.x para Azure Functions v4 y APIM | Invocación directa |
| [`frontend-design`](../skills/frontend-design/SKILL.md) | `frontend-design` | Orientar diseño visual distintivo solo cuando la superficie no tiene sistema de diseño declarado | Invocación directa; no aplica si el proyecto declara tokens, catálogo de componentes o assets de marca |
| [`file-organization-standards`](../skills/file-organization-standards/SKILL.md) | `file-organization-standards` | Reglas agnósticas de organización y granularidad | Invocación directa |
| [`ts-ecmascript-standards`](../skills/ts-ecmascript-standards/SKILL.md) | `ts-ecmascript-standards` | Buenas prácticas de TypeScript y ECMAScript | Invocación directa |
| [`commit-es`](../skills/commit-es/SKILL.md) | `commit-es` | Conventional Commits en español y JSDoc cuando aplica | Invocación directa |
| [`create-agentsmd`](../skills/create-agentsmd/SKILL.md) | `create-agentsmd` | Generar `AGENTS.md` para un repositorio | Invocación directa |

## Documentos y archivos de oficina

| Directorio | Nombre canónico | Responsabilidad | Modo de uso vigente |
|---|---|---|---|
| [`docx`](../skills/docx/SKILL.md) | `docx` | Crear, leer y editar documentos Word | Invocación directa |
| [`pdf`](../skills/pdf/SKILL.md) | `pdf` | Leer, crear, transformar y validar PDF | Invocación directa |
| [`pptx`](../skills/pptx/SKILL.md) | `pptx` | Crear, leer y editar presentaciones PowerPoint | Invocación directa |
| [`xlsx`](../skills/xlsx/SKILL.md) | `xlsx` | Crear, leer y editar hojas de cálculo | Invocación directa |

## Cobertura documental detallada

| Área | Documentación |
|---|---|
| Arquitectura | [Archi](./archi/README.md) |
| Implementación de aplicaciones | [Builder](./builder/README.md) |
| Arquitectura UX | [Iris](./iris/README.md) |
| Baseline y arquetipos | [Solution Baseline](./solution-baseline/README.md) |
| Modelado de dominio | [Storming](./storming/README.md) |
| Procesos de negocio | [Takumi](./takumi/README.md) |
| DevOps/IaC/operación | [Vulcano](./vulcano/README.md) |

## Validación estructural

Se ejecutó el validador vigente de `skill-creator` sobre los 26 directorios que existían el 10 de septiembre. `bancolombia-brand-manual` (válida en esa corrida) salió el 14 de septiembre, así que de los 25 actuales quedan 22 válidas sin repetir la corrida:

| Resultado | Cantidad | Detalle |
|---|---:|---|
| Válidas | 23 | Frontmatter y estructura aceptados |
| No conformes | 3 | `cupido`/`effort-estimator`, `epicureo` y `specter` usan la clave top-level `compatibility` |

El validador permite `allowed-tools`, `description`, `license`, `metadata` y `name`, pero no `compatibility` en el nivel superior. La corrección futura debe preservar la restricción de integración en el cuerpo o en metadata soportada. Hasta entonces, estas tres skills existen y pueden leerse, pero no deben reportarse como paquetes estructuralmente válidos. Después de corregir esa primera causa debe repetirse el validador, porque su salida actual no demuestra que no existan fallos posteriores.

## Reglas de identidad

- Invoque una skill por el `name` declarado en su frontmatter, no necesariamente por el nombre de la carpeta.
- Use `$storming` como identificador técnico; “Event Storming” o “EventStorming” nombran la técnica.
- Trate `cupido` como ruta física; el identificador publicado es `$effort-estimator`.
- Use `$solution-baseline` para trabajo nuevo. `$genesis` solo conserva compatibilidad histórica.
- Solo `solution-baseline` declara una célula de agentes especializada. Builder tiene un agente de entrada directa, no una célula ni un orquestador.
