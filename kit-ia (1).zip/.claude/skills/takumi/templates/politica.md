---
id: DOC-###
tipo_documento: "Politica"
slug: slug-de-la-politica
macroproceso: "[Macroproceso — ver resources/procesos/00-inventario-procesos.md]"
proceso: "[Proceso/subproceso al que aplica esta politica]"
version: 1
fecha: YYYY-MM-DD
estado: "Pendiente | En levantamiento | Borrador generado | Validado por el dueno"
responsable: "[Cargo que aprueba/emite la politica]"
hotspots_abiertos: 0
---

# DOC-###: [Nombre de la politica]

## Tabla de contenido

1. [Objeto](#1-objeto)
2. [Alcance](#2-alcance)
3. [Politica](#3-politica)
4. [Hotspots abiertos](#4-hotspots-abiertos)
5. [Notas de reuniones](#5-notas-de-reuniones)
6. [Control de cambios](#6-control-de-cambios)

## 1. Objeto

[proposito o razon de ser de la politica]

## 2. Alcance

[a quien aplica, que cubre, que queda fuera]

## 3. Politica

[declaracion de la politica en si — las reglas, principios o lineamientos obligatorios que se
establecen. Redacta cada lineamiento como una declaracion clara y verificable, no como una intencion
vaga]

## 4. Hotspots abiertos

| ID | Tipo | Descripcion | Pregunta concreta | Impacto si no se resuelve | Origen | Estado |
|---|---|---|---|---|---|---|
| | | | | | | |

## 5. Notas de reuniones

[Hallazgos de Meetings/ asignados a este documento, con fecha y archivo de origen]

## 6. Control de cambios

| Version | Fecha | Razon de la actualizacion |
|---|---|---|
| 1 | YYYY-MM-DD | Creacion del documento |

**Elaboro:** [ ] · **Reviso:** [ ] · **Aprobo:** [ ]
