---
id: ACTA-###
slug: slug-de-la-reunion
fecha: YYYY-MM-DD
proceso_relacionado: "[PROC-### y nombre, si esta reunion es parte de un levantamiento — o '—' si es general]"
version: 1
estado: "Borrador | Aprobada"
---

# ACTA-###: [Tema/objetivo de la reunion]

**Numero de acta:** ACTA-### · **Fecha:** YYYY-MM-DD · **Hora:** [ ] · **Lugar:** [ ]

**Elaborado por:** [ ]

**Objetivo de la reunion:** [ ]

**Asistentes:**

| Nombre | Rol/Cargo |
|---|---|
| | |

## Tabla de contenido

- [Agenda](#agenda)
- [Compromisos del acta anterior](#compromisos-del-acta-anterior)
- [Desarrollo tematico](#desarrollo-tematico)
- [Documentos anexos](#documentos-anexos)
- [Acuerdos o compromisos](#acuerdos-o-compromisos)
- [Proxima reunion](#proxima-reunion)
- [Control de cambios](#control-de-cambios)

## Agenda

| Item | Tema |
|---|---|
| 1 | |

## Compromisos del acta anterior

| Item | Compromiso | Responsable | Fecha de entrega |
|---|---|---|---|
| | | | |

## Desarrollo tematico

[Narrativa de lo discutido, organizada por punto de agenda]

## Documentos anexos

| Item | Tema |
|---|---|
| | |

## Acuerdos o compromisos

| Item | Compromiso | Responsable | Fecha de entrega |
|---|---|---|---|
| | | | |

## Proxima reunion

**Fecha:** [ o "No se acordo"]

## Control de cambios

| Version | Fecha | Descripcion de la actualizacion |
|---|---|---|
| 1 | YYYY-MM-DD | Creacion del documento |

**Elaboro:** [ ] · **Reviso:** [ ] · **Aprobo:** [ ]
