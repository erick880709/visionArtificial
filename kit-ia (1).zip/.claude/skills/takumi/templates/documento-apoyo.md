---
id: DOC-###
tipo_documento: "Documento de apoyo"
slug: slug-del-documento
macroproceso: "[Macroproceso — ver resources/procesos/00-inventario-procesos.md]"
proceso: "[Proceso/subproceso al que apoya este documento]"
version: 1
fecha: YYYY-MM-DD
estado: "Pendiente | En levantamiento | Borrador generado | Validado por el dueno"
responsable: "[Cargo]"
hotspots_abiertos: 0
---

# DOC-###: [Nombre del documento de apoyo]

## Tabla de contenido

1. [Objeto del documento](#1-objeto-del-documento)
2. [Alcance](#2-alcance)
3. [Documentos relacionados](#3-documentos-relacionados)
4. [Desarrollo](#4-desarrollo)
5. [Mejoras identificadas](#5-mejoras-identificadas-omitir-si-el-documento-no-describe-una-actividad-operativa)
6. [Oportunidades de automatizacion / IA](#6-oportunidades-de-automatizacion--ia-omitir-si-el-documento-no-describe-una-actividad-operativa)
7. [Hotspots abiertos](#7-hotspots-abiertos)
8. [Notas de reuniones](#8-notas-de-reuniones)
9. [Control de cambios](#9-control-de-cambios)

## 1. Objeto del documento

[proposito o razon de ser del documento de apoyo]

## 2. Alcance

[donde inicia, que cubre, donde termina]

## 3. Documentos relacionados

[documentos que soportan la ejecucion de las actividades que este documento acompana]

## 4. Desarrollo

[contenido libre — este tipo de documento no tiene composicion interna fija; varia segun lo que se
necesite describir (lineamientos, criterios, metodologias, plantillas de apoyo, guias). Estructura el
contenido con los encabezados que tengan sentido para este caso especifico]

## 5. Mejoras identificadas *(omitir si el documento no describe una actividad operativa)*

| Oportunidad | Relacionado con | Descripcion | Lente/patron aplicado | Esfuerzo | Impacto | Tipo de solucion sugerida |
|---|---|---|---|---|---|---|
| | | | | | | |

## 6. Oportunidades de automatizacion / IA *(omitir si el documento no describe una actividad operativa)*

| Oportunidad | Relacionado con | Descripcion | Esfuerzo | Impacto | Tipo de solucion sugerida |
|---|---|---|---|---|---|
| | | | | | |

## 7. Hotspots abiertos

| ID | Tipo | Descripcion | Pregunta concreta | Impacto si no se resuelve | Origen | Estado |
|---|---|---|---|---|---|---|
| | | | | | | |

## 8. Notas de reuniones

[Hallazgos de Meetings/ asignados a este documento, con fecha y archivo de origen]

## 9. Control de cambios

| Version | Fecha | Razon de la actualizacion |
|---|---|---|
| 1 | YYYY-MM-DD | Creacion del documento |

**Elaboro:** [ ] · **Reviso:** [ ] · **Aprobo:** [ ]
