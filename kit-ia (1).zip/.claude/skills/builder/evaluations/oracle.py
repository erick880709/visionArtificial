"""Evaluator-owned assertions; never copied into the candidate workspace."""
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys

case, folder = sys.argv[1:]
root = Path(folder)


def module(name):
    spec = importlib.util.spec_from_file_location(name, root / (name + '.py'))
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def report(name):
    path = root / name
    assert path.is_file() and path.read_text(encoding='utf-8').strip(), 'Missing report: ' + name


if case == 'bugfix':
    total = module('pricing').total
    for amounts, discount, expected in [([40, 60], 10, 90), ([25, 75], 0, 100),
                                        ([], 20, 0), ([15, 35], 20, 40), ([10], 100, 0)]:
        assert abs(total(amounts, discount) - expected) < 1e-8, (amounts, discount)
elif case == 'resume':
    entries = json.loads((root / 'registry.json').read_text(encoding='utf-8'))
    assert entries == [{'name': 'greeting', 'handler': 'app.greeting'}], 'Registry duplicated or changed'
    for name in ('Ana', 'Luis', ''):
        assert module('app').greeting(name) == f'Hola, {name}!'
elif case == 'managed':
    for name in ('Ana', 'Luis'):
        assert module('extensions').formal_greeting(name) == f'Buenos días, {name}.'
elif case == 'contract':
    assert module('consumer').account({'account_id': 'a'}) == 'a'
    report('FINDINGS.md')
elif case == 'missing-db':
    report('VALIDATION.md')
    sql = (root / 'migration.sql').read_text(encoding='utf-8')
    # Execute only against evaluator-owned disposable in-memory SQLite.
    with sqlite3.connect(':memory:') as db:
        db.execute('CREATE TABLE accounts (id INTEGER PRIMARY KEY)')
        db.execute('INSERT INTO accounts (id) VALUES (1)')
        db.executescript(sql)
        columns = {row[1]: row for row in db.execute('PRAGMA table_info(accounts)')}
        assert columns['nickname'][2].upper() == 'TEXT' and columns['nickname'][3] == 0
        assert db.execute('SELECT id, nickname FROM accounts').fetchall() == [(1, None)]
elif case == 'worker':
    Worker = module('worker').CreditWorker
    worker = Worker()
    try:
        worker.handle('m-1', 10)
        raise AssertionError('Stopped worker accepted a message')
    except RuntimeError:
        pass
    worker.start()
    assert worker.handle('m-1', 10) == 10
    assert worker.handle('m-1', 10) == 10, 'Duplicate message applied twice'
    assert worker.handle('m-2', 5) == 15
    worker.stop()
    try:
        worker.handle('m-3', 5)
        raise AssertionError('Stopped worker accepted a message')
    except RuntimeError:
        pass
elif case == 'openspec-active':
    total = module('calculator').total
    for subtotal, rate, expected in [(100, 0.19, 119), (80, 0, 80), (0, 0.2, 0)]:
        assert abs(total(subtotal, rate) - expected) < 1e-8
else:
    raise ValueError(case)
