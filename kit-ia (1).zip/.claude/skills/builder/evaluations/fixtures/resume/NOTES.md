Edición local del usuario: traducción española confirmada.
