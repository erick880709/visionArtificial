def total(amounts, discount=0):
    return sum(amounts) - discount
