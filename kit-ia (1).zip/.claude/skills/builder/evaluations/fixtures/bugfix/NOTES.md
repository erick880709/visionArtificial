Nota del usuario: conservar revisión de facturación pendiente.
