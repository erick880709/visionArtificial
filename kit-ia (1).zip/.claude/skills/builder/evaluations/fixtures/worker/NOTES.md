Conservar: el transporte confirma el mensaje después de que handle termina.
