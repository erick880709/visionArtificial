def greeting(name):
    return 'Hola, ' + name
