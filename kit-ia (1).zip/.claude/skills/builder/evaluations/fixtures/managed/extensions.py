# Punto de extensión permitido para saludos adicionales.
