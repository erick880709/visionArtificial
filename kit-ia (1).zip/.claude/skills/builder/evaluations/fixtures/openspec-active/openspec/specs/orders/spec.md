# Orders

El total vigente equivale al subtotal antes de impuestos.
