# Delta: tax

## MODIFIED Requirements

El total devuelve subtotal más `subtotal * tax_rate`.
