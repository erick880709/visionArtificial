def total(subtotal, tax_rate):
    return subtotal
