# Diagnóstico y revisión

## Diagnóstico dirigido por evidencia

Antes de corregir un defecto, expresa el síntoma observable, el comportamiento
esperado y el límite donde aparece. Sigue datos y control por el entrypoint real.
Formula una hipótesis que prediga una observación discriminante; ejecuta el
experimento más pequeño capaz de refutarla y registra resultado, no solo la acción.

No acumules cambios para probar varias causas a la vez. Tras un intento fallido,
revierte únicamente el experimento propio si es seguro, conserva la evidencia y
actualiza la hipótesis. Si dos intentos consecutivos no cambian la evidencia o el
mismo supuesto vuelve a fallar, deja de parchear: amplía instrumentación, revisa el
límite anterior o identifica el dato faltante. El número orienta la revisión, no
autoriza descartar una pista nueva ni convierte automáticamente la tarea en bloqueo.

Detén el diagnóstico cuando una causa explique el síntoma y una comprobación pueda
distinguir la versión defectuosa de la corregida. Si no hay reproducción, entrega
las hipótesis descartadas, evidencia obtenida y condición necesaria para continuar;
no presentes correlación, silencio de logs o un test incapaz de fallar como causa.

## Revisión en dos perspectivas

Revisa primero **cumplimiento** usando la fuente funcional y los criterios, sin
dejar que la forma del código redefina el resultado:

- comportamiento requerido, errores y escenarios negativos pertinentes;
- preservación, compatibilidad, ownership y ausencia de cambios fuera de alcance;
- cableado y entrypoints que demuestren que la implementación se usa;
- evidencia ejecutada contra la revisión actual.

Resuelve los incumplimientos antes de aceptar la entrega. Después revisa **calidad**:
claridad, consistencia con el repositorio, complejidad accidental, seguridad,
operabilidad y mantenibilidad proporcionales al cambio. Clasifica hallazgos por
impacto observable; una preferencia estilística compatible no bloquea cumplimiento.

Un cambio ligero permite ambas perspectivas en la misma inspección. Usa revisor
independiente solo cuando el riesgo, la incertidumbre o la separación de ownership
lo justifiquen y exista capacidad; entrégale criterios y diff, no la conclusión
deseada. El autor reconcilia sus hallazgos con evidencia y vuelve a ejecutar las
comprobaciones afectadas. No marques calidad aprobada porque los tests estén verdes,
ni cumplimiento aprobado porque el diseño parezca limpio.
