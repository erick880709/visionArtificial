# Guía: Pilares Well-Architected

Complementa `08-Well-Architected.md`. A diferencia del QAW (`07`), que prioriza según lo que los stakeholders traen a la mesa, el Well-Architected Review es una revisión **holística**: todos los pilares se evalúan, hayan sido o no mencionados en el QAW. Un `QA-xx` priorizado enriquece el análisis de su pilar relacionado, pero **no decide si el pilar se evalúa** — eso lo decide esta guía.

## Catálogo de pilares (agnóstico de nube)

| Pilar | Definición | Prácticas de ejemplo | AWS | Azure | GCP |
|---|---|---|---|---|---|
| Excelencia Operacional | Capacidad de operar, monitorear y mejorar el sistema en producción | Runbooks, despliegues automatizados, IaC, gestión de incidentes, mejora continua | Operational Excellence | Operational Excellence | Operational Excellence |
| Seguridad | Proteger datos, sistemas y activos mientras se entrega valor | Defensa en profundidad, mínimo privilegio, cifrado en tránsito/reposo, gestión de identidad, respuesta a incidentes | Security | Security | Security |
| Confiabilidad | Capacidad de recuperarse de fallos y satisfacer la demanda | Recuperación ante desastres, auto-healing, pruebas de resiliencia, gestión de cambios | Reliability | Reliability | Reliability |
| Eficiencia de Rendimiento | Uso eficiente de recursos de cómputo para cumplir requisitos | Selección de tipo de recursos según carga, escalado elástico, monitoreo de latencia, revisión periódica de arquitectura | Performance Efficiency | Performance Efficiency | Performance Optimization |
| Optimización de Costos | Evitar gasto innecesario mientras se cumplen los objetivos | Right-sizing, instancias reservadas/spot, apagado de ambientes no productivos, monitoreo de costos por etiqueta | Cost Optimization | Cost Optimization | Cost Optimization |
| Sostenibilidad | Minimizar el impacto ambiental de las cargas de trabajo | Selección de regiones de menor huella de carbono, right-sizing, arquitecturas serverless/elásticas que evitan sobre-aprovisionamiento | Sustainability | (integrado en Cost/Operational Excellence — Microsoft no lo trata como pilar formal) | Sustainability |

Si el proyecto ya confirmó un proveedor de nube único, usa el nombre y agrupación oficial de ese proveedor en `08`; si es multi-nube o agnóstico, usa esta tabla como referencia neutral.

## Cómo usarlo en `08-Well-Architected.md`

1. Recorre los 6 pilares de la tabla — ninguno queda sin fila en la matriz de cobertura (ver plantilla en `references/plantilla-documento-arquitectura.md`).
2. Para cada pilar, revisa si algún `QA-xx` priorizado en `07` le aplica directamente: si sí, deriva principios/prácticas (`PD-xx`/`BP-xxx`) de ese escenario.
3. Si ningún `QA-xx` prioritario toca el pilar, igual documenta al menos una recomendación base (ej. Seguridad y Confiabilidad casi nunca se marcan "No aplica" en un sistema con datos de negocio) o márcalo **No aplica** con un motivo concreto (ej. Sostenibilidad en una carga de trabajo interna, bajo volumen, sin objetivo de sostenibilidad del cliente).
4. No marques "No aplica" solo porque el QAW no lo mencionó — eso es "Considerado y descartado" (con motivo), un estado distinto: úsalo cuando sí se evaluó el pilar pero se concluyó que no amerita prácticas adicionales a las que ya trae el enfoque elegido.

## Fuente

AWS Well-Architected Framework, Microsoft Azure Well-Architected Framework y Google Cloud Architecture Framework. Los nombres de pilar difieren levemente entre proveedores; la tabla usa la terminología más extendida (AWS) como base neutral.
