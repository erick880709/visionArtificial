# Diagramas adicionales en Mermaid: sintaxis y ejemplos

Complementan al C4 cuando este no cubre suficiente detalle sobre un flujo, el modelo de datos o la infraestructura. Inclúyelos solo cuando aporten información nueva — no dupliques en texto lo que el diagrama ya muestra.

## Diagramas de secuencia (obligatorios para flujos críticos)

Muestran el orden temporal de interacciones entre componentes/actores para UN caso de uso concreto. Son la herramienta más efectiva para explicar "qué pasa cuando el usuario hace X" — genera uno por cada flujo de negocio crítico (autenticación, el o los casos de uso principales, cualquier flujo con pasos asíncronos o múltiples servicios).

```mermaid
sequenceDiagram
    title Flujo: Creación de un Pedido

    actor Cliente
    participant WebApp as Aplicación Web
    participant API as API de Pedidos
    participant Validador as ValidadorPedido
    participant DB as Base de Datos
    participant Pasarela as Pasarela de Pago
    participant Cola as Cola de Mensajes
    participant Worker as Worker de Notificaciones

    Cliente->>WebApp: Confirma pedido
    WebApp->>API: POST /pedidos
    API->>Validador: validar(datosPedido)
    Validador-->>API: OK

    API->>Pasarela: Procesar pago
    Pasarela-->>API: Pago aprobado

    API->>DB: INSERT pedido
    DB-->>API: pedido creado (id)

    API->>Cola: Publica evento "PedidoCreado"
    API-->>WebApp: 201 Created (id pedido)
    WebApp-->>Cliente: Confirmación visual

    Cola->>Worker: Consume evento "PedidoCreado"
    Worker->>Worker: Genera email de confirmación
```

Buenas prácticas:
- Incluye rutas alternativas o de error cuando sean relevantes al negocio (ej. pago rechazado), usando `alt`/`else` de Mermaid, en vez de crear un diagrama separado para cada variante menor.
- En Caso B (AS-IS), el diagrama debe reflejar lo que el código hace realmente, incluyendo atajos o inconsistencias — no "limpies" el flujo al documentarlo.

## Diagrama de despliegue

> **Si el proveedor de nube es AWS, Azure o GCP, no uses Mermaid para este diagrama.** Genera un archivo `.drawio` con la iconografía oficial de cada proveedor — ver `references/drawio-iconos-nube.md` (y `references/guia-multi-cloud-deployment.md` / `references/guia-terraform-a-diagrama.md` según el caso). El `graph TB` de esta sección queda solo como **fallback** para infraestructura on-premise o proveedores sin librería de iconos disponible.

Útil cuando la topología de infraestructura no es obvia: múltiples ambientes, regiones, redes, orquestación de contenedores. Se puede modelar como un grafo con `graph` o con la sintaxis `C4Deployment` si el visor la soporta; `graph TB` es más portable:

```mermaid
graph TB
    subgraph "Región: us-east-1"
        subgraph "Cluster Kubernetes"
            subgraph "Namespace: produccion"
                pod1["Pod: API de Pedidos (x3 réplicas)"]
                pod2["Pod: Worker de Notificaciones (x2 réplicas)"]
            end
        end
        lb["Load Balancer"]
        rds[("RDS PostgreSQL - Multi-AZ")]
        redis[("ElastiCache Redis")]
    end

    cdn["CDN / CloudFront"]
    s3[("S3 - Assets estáticos")]

    Internet -->|HTTPS| cdn
    cdn --> s3
    Internet -->|HTTPS| lb
    lb --> pod1
    pod1 --> rds
    pod1 --> redis
    pod2 --> rds
```

## Diagrama entidad-relación por contenedor

Inclúyelo en el `16.xx` del contenedor significativo cuando su modelo sea relevante y no trivial. `16-Modelo-de-Datos.md` conserva únicamente el mapa global de ownership y los enlaces; no mezcles en un único ER las tablas privadas de varios microservicios como si compartieran base de datos. Sigue `references/guia-diseno-detallado-contenedores.md`.

```mermaid
erDiagram
    CLIENTE ||--o{ PEDIDO : realiza
    PEDIDO ||--|{ ITEM_PEDIDO : contiene
    PRODUCTO ||--o{ ITEM_PEDIDO : referenciado_en
    PEDIDO }o--|| ESTADO_PEDIDO : tiene

    CLIENTE {
        uuid id PK
        string email
        string nombre
    }
    PEDIDO {
        uuid id PK
        uuid cliente_id FK
        decimal total
        string estado
        timestamp creado_en
    }
    ITEM_PEDIDO {
        uuid id PK
        uuid pedido_id FK
        uuid producto_id FK
        int cantidad
        decimal precio_unitario
    }
    PRODUCTO {
        uuid id PK
        string nombre
        decimal precio
        int stock
    }
```

## Diagrama de componentes/clases (fuera del C4 Nivel 4)

Si necesitas mostrar relaciones de herencia/composición más finas que el C4 Nivel 3, usa `classDiagram` (ver ejemplo completo en `diagramas-c4-ejemplos.md`, sección Nivel 4).

## Diagrama de dominio (modelo conceptual DDD)

Distinto del diagrama de clases de código y del modelo de datos de `16-Modelo-de-Datos.md`: aquí el objetivo es mostrar los **conceptos de negocio** y sus relaciones (agregados, entidades, value objects) en el lenguaje ubicuo del dominio, sin atributos técnicos ni claves foráneas. Útil cuando el proyecto usa Event Storming o DDD y el dominio tiene reglas de negocio no triviales que ni el C4 ni el modelo de datos comunican por sí solos.

```mermaid
classDiagram
    class Pedido {
        <<Aggregate Root>>
        +confirmar()
        +cancelar()
    }
    class ItemPedido {
        <<Entity>>
    }
    class Dinero {
        <<Value Object>>
    }
    Pedido "1" *-- "1..*" ItemPedido : contiene
    ItemPedido --> Dinero : precio
```

Genera este diagrama solo si el modelo de dominio no es evidente desde el C4 Componentes y el modelo de datos — no lo dupliques si ambos ya cuentan la misma historia.

## Diagrama de paquetes

Muestra la organización de módulos/paquetes de código y sus dependencias — útil cuando el C4 Nivel 3 (Componentes) no alcanza a explicar cómo está physically organizado el código (ej. capas, módulos por bounded context) o cuando hay una regla de dependencia que el equipo debe respetar (ej. "dominio no depende de infraestructura").

```mermaid
graph TB
    subgraph "com.empresa.pedidos"
        api["api (controllers)"]
        dominio["dominio (entidades, reglas)"]
        infraestructura["infraestructura (repositorios, adaptadores)"]
    end

    api --> dominio
    infraestructura --> dominio
    api -.->|"no debe depender de"| infraestructura
```

En Caso B (AS-IS), solo incluye dependencias verificables en el código real; si el equipo declara una regla de dependencia que el código no respeta, documenta la violación como hallazgo en `21-Riesgos-y-Deuda-Tecnica.md`, no la "corrijas" en el diagrama.

## Regla general

Cada diagrama de este archivo es condicional, a diferencia de los C4 (que siempre van niveles 1-3) y las secuencias de flujos críticos (que siempre van). Pregúntate: "¿este diagrama le dice al lector algo que el texto y los otros diagramas no le dicen ya?" Si la respuesta es no, no lo incluyas.
