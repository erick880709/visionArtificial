# Branding PersonalSoft para Propuestas de Estimación

Esta skill **siempre** genera su PPTX ejecutivo a partir de la plantilla corporativa bundleada en `assets/branding/Plantilla_PPT_Corporativa_PersonalSoft.pptx` — nunca desde un tema genérico de `pptxgenjs`. Sigue el flujo de edición de plantillas de la skill `pptx` (`unzip → editar ppt/slides/slideN.xml → zip`), no reconstruyas el diseño desde cero.

## Paleta de colores (extraída de la plantilla, úsala tal cual)

| Uso | Color | Hex |
|---|---|---|
| Azul marca / títulos y acentos | Azul PersonalSoft | `0E337C` |
| Azul marca alternativo (portada/cierre) | Azul oscuro | `263474` |
| Texto de cuerpo | Casi negro | `222222` |
| Fondo claro / texto sobre fondo oscuro | Blanco | `FFFFFF` |

No introduzcas otros colores de acento — si una tabla o gráfico necesita una paleta categórica (ej. Tradicional vs. IA, o por rol), deriva variaciones de tono/saturación de estos dos azules en vez de traer colores nuevos ajenos a la marca.

**Tipografía:** Arial (con `DejaVu Sans` como fallback del tema) — no cambies de familia tipográfica.

## Mapeo de slides de la plantilla a las secciones de esta skill

La plantilla trae 15 slides de ejemplo (tema DevOps, irrelevante para el contenido). Úsalas como **layouts/estructura**, reemplazando el contenido, no como referencia temática:

| Slide de la plantilla | Layout que aporta | Úsala para |
|---|---|---|
| `slide1.xml` | Portada — fondo oscuro con imagen abstracta, título + subtítulo en blanco, logo inferior | Portada de la propuesta: nombre de la necesidad/proyecto + "Propuesta de Estimación de Esfuerzo" |
| `slide2.xml` / `slide3.xml` | Contenido con título superior + línea divisoria azul + cuerpo (una o dos columnas) | Contexto de negocio, épica(s) de `epicureo`, alcance/exclusiones |
| `slide4.xml` | Split de dos tonos (mitad clara/mitad con bloque de color) | Resumen ejecutivo (Story Points/horas, días, costo) — usa el bloque de color para las cifras clave |
| `slide5.xml` / `slide6.xml` | Contenido con gráfico/diagrama embebido | Comparativo Tradicional vs. IA (SDD), distribución de esfuerzo por rol (como gráfico de barras/dona, no tabla, en el PPTX) |
| `slide7.xml`–`slide12.xml` | Tabla de fases con "Objetivo / Se define / Entregables" | Proyección de sprints/iteraciones o fases (adapta el patrón "Fase N" a los sprints/iteraciones reales de la propuesta) |
| `slide14.xml` | Divisor — fondo azul sólido, solo logo | Separador entre secciones si el PPTX ejecutivo crece más de ~8 slides (ej. antes de "Historias de alto riesgo") |
| `slide15.xml` | Cierre — fondo azul, logo centrado, "We make it happen" | Última slide: cierre + vigencia de la propuesta + próximos pasos |

**Slots del template ≠ tus datos:** si una slide de fases trae espacio para 6 fases y tu proyección solo tiene 3 sprints, elimina los grupos sobrantes completos (no solo el texto) — ver la sección de gotchas de la skill `pptx` sobre slots vs. source items.

## Reglas para el PPTX ejecutivo de esta skill

- Máximo 10–12 slides (ya establecido en el `SKILL.md`) — portada, resumen ejecutivo, épica(s) (resumida, remite al HTML para el enunciado completo si son varias), comparativo Tradicional vs. IA, distribución por rol, proyección de sprints/iteraciones, historias/épicas de alto riesgo, vigencia y próximos pasos, cierre.
- Todas las cifras deben coincidir exactamente con el `.md` fuente de verdad y con el `.html` — la plantilla nunca es excusa para redondear distinto en cada formato.
- Reutiliza el logo y los elementos de marca duplicando slides/grupos existentes de la plantilla (`add_slide.py`), nunca recreando el logo o el fondo abstracto de la portada a mano.
- Corre `validate.py output.pptx --original assets/branding/Plantilla_PPT_Corporativa_PersonalSoft.pptx` antes de entregar — el flag `--original` evita falsos positivos de la XSD propia de la plantilla.

## Reglas para el HTML detallado

El HTML no viene de una plantilla de archivo, pero debe verse como parte de la misma marca:
- Encabezado del documento con el nombre "PersonalSoft" y los azules `0E337C`/`263474` como color de acento (títulos de sección, bordes de `callout`, encabezados de tabla) — no un azul genérico de framework CSS.
- Mantén el esquema claro/oscuro con `prefers-color-scheme` ya usado en `resources/estimation/` de este proyecto, pero ancla los acentos a esta paleta en ambos modos (en modo oscuro, usa una versión más clara de `0E337C` para mantener contraste, no un azul distinto).
- Tipografía del cuerpo: una sans-serif del sistema (Arial/Helvetica) para ser consistente con el PPTX, sin necesidad de cargar la fuente exacta vía web font.
