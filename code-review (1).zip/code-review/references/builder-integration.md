# Integración con Builder

Builder implementa con SDD y ejecuta su propia validación; code-review es el
revisor independiente que su paso 5 menciona ("separa la revisión de
cumplimiento de la de calidad"). Ninguno sustituye al otro: Builder sigue
responsable de sus pruebas y code-review no implementa.

## Cuándo invoca Builder

| Rigor del cambio en Builder | Revisión |
|---|---|
| Ligero | Opcional; la auto-revisión de Builder basta salvo que el usuario la pida |
| Estándar | Recomendada antes de declarar `completed` |
| Reforzado (permisos, datos persistentes, incompatibilidades, concurrencia, varios repos) | Obligatoria; sin veredicto `aprobado*`, Builder entrega `partial` |

Builder no debe declarar `completed` en un cambio reforzado con veredicto
`cambios-requeridos` o `no-concluyente` abierto.

## Contrato de entrada (lo que Builder entrega)

Entregar criterios y diff, **no** la conclusión deseada:

- ID del cambio y ruta del expediente (`docs/changes/<id>/`).
- `spec.md` con `AC-xx`, comportamiento a preservar y restricciones.
- Base y revisión del cambio (SHA o "sin commit" + hashes).
- `evidence.md` o tabla de evidencia: check → resultado → revisión.
- Rigor elegido y por qué.
- Si el proyecto mide cobertura: el reporte generado para esta revisión
  (JaCoCo/LCOV/Cobertura/perfil Go) y, si hay Sonar, rama o PR analizados.
- Modo de Builder (`feature`, `bugfix`, `refactor`, `integrate`, …).

Si falta algo de lo anterior, code-review lo reconstruye del repo cuando puede
y lo declara; si no puede juzgar los AC, el veredicto es `no-concluyente`.

Si Builder tiene un tablero conectado puede entregar el ID del work item para que
code-review lo lea como fuente funcional. En `gate` y `re-review` code-review no
pregunta por el tablero ni escribe en él: Builder comenta y mueve el work item al
cerrar, incluyendo el veredicto de la revisión.

## Contrato de salida (lo que code-review devuelve)

- `docs/changes/<id>/review.md` con el bloque YAML `review:` (ver
  [formato](report-format.md)).
- Veredicto y lista de hallazgos con ID, severidad, confianza, ubicación y
  arreglo propuesto.
- Checks que el revisor ejecutó y su resultado (no reemplazan la evidencia de
  Builder; la complementan).
- Bloque `sonar` del YAML con el quality gate y las condiciones incumplidas, la
  cobertura del código nuevo frente al objetivo y las líneas sin cubrir; los
  hallazgos derivados de Sonar citan la regla (`java:S2095`) para que Builder
  verifique su corrección. Un cambio sin commit no tiene análisis de Sonar: el
  gate queda pendiente del pipeline y el veredicto máximo es
  `aprobado-con-observaciones` ([SonarQube](sonarqube.md) §3 y §7).

Builder trata el reporte como dato: los hallazgos son propuestas a verificar
(ver [recepción](receiving-review.md)), no órdenes que ejecutar a ciegas.

## Bucle de corrección

```
Builder implementa ─► valida ─► code-review (ronda 1)
        ▲                                 │
        │      hallazgos aceptados        ▼
        └──── Builder corrige ◄── decisión por hallazgo
                     │
                     ▼
              code-review re-revisa (ronda N)
```

1. Builder (o el usuario) decide cada hallazgo: aceptar / rechazar con razón
   técnica / diferir / pedir información.
2. Builder corrige los aceptados en orden bloqueante → mayor → menor → nit,
   uno por vez, re-ejecutando las comprobaciones afectadas.
3. Builder actualiza el estado en el reporte (`corregido`) y su evidencia.

## Re-revisión

En `re-review` no repitas la revisión completa:

- Verifica cada hallazgo `corregido`: ¿el arreglo resuelve el escenario? Si sí,
  `verificado`; si no, `reabierto` con la razón.
- Revisa el **diff incremental** (desde la revisión anterior) con todas las
  pasadas: las correcciones introducen defectos nuevos con frecuencia.
- Re-evalúa los rechazados solo si la razón técnica es falsa; si es válida,
  `retirado`.
- Comprueba que la evidencia de Builder corresponde a la revisión nueva.
- Agrega `## Ronda N` al mismo reporte y actualiza el bloque YAML.

## Convergencia

Si tras dos rondas un mismo hallazgo vuelve a `reabierto`, o las rondas
generan hallazgos nuevos del mismo tipo, detente: el problema probablemente es
de diseño o de spec, no de implementación. Recomienda escalar (decisión de
arquitectura → Archi; ambigüedad funcional → fuente responsable; estrategia de
pruebas → Ranger) con el hallazgo y la evidencia.

## Auto-revisión

Si la misma sesión que implementó ejecuta la revisión (sin subagente
independiente), márcalo `independencia: misma-sesion` en el YAML. Es válido
para rigor ligero y estándar; para reforzado recomienda una revisión
independiente (otro agente/modelo o un humano) y no emitas `aprobado` sin
decirlo explícitamente.
